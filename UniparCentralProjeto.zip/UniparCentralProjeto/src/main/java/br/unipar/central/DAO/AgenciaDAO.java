package br.unipar.central.DAO;

import br.unipar.central.models.AgenciaModels;
import br.unipar.central.util.DataBase;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AgenciaDAO {

    // Declaração de constantes SQL
    private static final String INSERT = "INSERT INTO agencia (id, codigo, digito, razaosocial, cnpj, ra, banco_id) VALUES (?, ?, ?, ?, ?, ?, ?)";
    private static final String FIND_ALL = "SELECT id, codigo, digito, razaosocial, cnpj, ra, banco_id FROM agencia";
    private static final String FIND_BY_ID = "SELECT id, codigo, digito, razaosocial, cnpj, ra, banco_id FROM agencia WHERE id = ?";
    private static final String DELETE_BY_ID = "DELETE FROM agencia WHERE id = ?";
    private static final String UPDATE = "UPDATE agencia SET codigo = ?, digito = ?, razaosocial = ?, cnpj = ?, ra = ?, banco_id = ? WHERE id = ?";

    // Busca todas as agências
    public List<AgenciaModels> findAll() throws SQLException {
        List<AgenciaModels> agencias = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = new DataBase().getConnection();
            pstmt = conn.prepareStatement(FIND_ALL);
            rs = pstmt.executeQuery();

            // Itera através do resultado da query e adiciona as agências na lista
            while (rs.next()) {
                AgenciaModels agencia = new AgenciaModels();
                agencia.setId(rs.getInt("id"));
                agencia.setCodigo(rs.getString("codigo"));
                agencia.setDigito(rs.getString("digito"));
                agencia.setRazaoSocial(rs.getString("razaosocial"));
                agencia.setCnpj(rs.getString("cnpj"));
                agencia.setRa(rs.getString("ra"));
                agencia.setBanco(new BancoDAO().findById(rs.getInt("banco_id")));

                agencias.add(agencia);
            }
        } finally {
            // Fecha as conexões
            if (rs != null) {
                rs.close();
            }
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

        return agencias;
    }

    // Busca uma agência por ID
    public AgenciaModels findById(int id) throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        AgenciaModels agencia = null;

        try {
            conn = new DataBase().getConnection();
            pstmt = conn.prepareStatement(FIND_BY_ID);
            pstmt.setInt(1, id);
            rs = pstmt.executeQuery();

            // Atribui os valores encontrados em um objeto AgenciaModels
            while (rs.next()) {
                agencia = new AgenciaModels();
                agencia.setId(rs.getInt("id"));
                agencia.setCodigo(rs.getString("codigo"));
                agencia.setDigito(rs.getString("digito"));
                agencia.setRazaoSocial(rs.getString("razaosocial"));
                agencia.setCnpj(rs.getString("cnpj"));
                agencia.setRa(rs.getString("ra"));
                agencia.setBanco(new BancoDAO().findById(rs.getInt("banco_id")));
            }
        } finally {
            // Fecha as conexões
            if (rs != null) {
                rs.close();
            }
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

        return agencia;
    }

    // Insere uma nova agência
    public void insert(AgenciaModels agencia) throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = new DataBase().getConnection();
            pstmt = conn.prepareStatement(INSERT);

            // Define os valores dos parâmetros
            pstmt.setInt(1, agencia.getId());
            pstmt.setString(2, agencia.getCodigo());
            pstmt.setString(3, agencia.getDigito());
            pstmt.setString(4, agencia.getRazaoSocial());
            pstmt.setString(5, agencia.getCnpj());
            pstmt.setString(6, agencia.getRa());
            pstmt.setInt(7, agencia.getBanco().getId());

            pstmt.executeUpdate();
        } finally {
            // Fecha as conexões
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
    }

    // Atualiza uma agência existente
    public void update(AgenciaModels agencia) throws SQLException {
Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = new DataBase().getConnection();
            pstmt = conn.prepareStatement(UPDATE);

            // Define os valores dos parâmetros
            pstmt.setString(1, agencia.getCodigo());
            pstmt.setString(2, agencia.getDigito());
            pstmt.setString(3, agencia.getRazaoSocial());
            pstmt.setString(4, agencia.getCnpj());
            pstmt.setString(5, agencia.getRa());
            pstmt.setInt(6, agencia.getBanco().getId());
            pstmt.setInt(7, agencia.getId());

            pstmt.executeUpdate();
        } finally {
            // Fecha as conexões
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
    }

    // Deleta uma agência por ID
    public void delete(int id) throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = new DataBase().getConnection();
            pstmt = conn.prepareStatement(DELETE_BY_ID);
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } finally {
            // Fecha as conexões
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
    }
}