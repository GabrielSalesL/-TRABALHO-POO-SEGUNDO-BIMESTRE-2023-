package br.unipar.central.DAO;

import br.unipar.central.models.AgenciaModels;
import br.unipar.central.models.BancoModels;
import br.unipar.central.util.DataBase;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BancoDAO {

    // Declara as consultas SQL como constantes para evitar erros de digitação
    private static final String INSERT = "INSERT INTO banco(id, nome, ra) VALUES(?, ?, ?)";
    private static final String FIND_ALL = "SELECT id, nome, ra FROM banco ";
    private static final String FIND_BY_ID = "SELECT id, nome, ra FROM banco WHERE id = ? ";
    private static final String DELETE_BY_ID = "DELETE FROM banco WHERE id = ?";
    private static final String UPDATE = "UPDATE banco SET  nome = ?, ra = ? WHERE ID = ?";

    // Busca todas as linhas na tabela Banco e retorna uma lista de objetos BancoModels
    public List<BancoModels> findAll() throws SQLException {
        ArrayList<BancoModels> retorno = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            // Abre uma conexão com o banco de dados
            conn = new DataBase().getConnection();

            // Prepara uma declaração SQL para buscar todas as linhas na tabela Banco
            pstmt = conn.prepareStatement(FIND_ALL);

            // Executa a declaração SQL e armazena o resultado em um objeto ResultSet
            rs = pstmt.executeQuery();

            // Itera sobre o ResultSet e adiciona cada linha como um objeto BancoModels na lista de retorno
            while (rs.next()) {
                BancoModels banco = new BancoModels();
                banco.setId(rs.getInt("id"));
                banco.setNome(rs.getString("nome"));
                banco.setRa(rs.getString("ra"));
                retorno.add(banco);
            }
        } finally {
            // Fecha o ResultSet, PreparedStatement e Connection, caso não tenham sido fechados ainda
            if (rs != null) {
                rs.close();
            }
            if (conn != null) {
                conn.close();
            }
            if (pstmt != null) {
                pstmt.close();
            }
        }

        // Retorna a lista de objetos BancoModels
        return retorno;
    }

    // Busca uma única linha na tabela Banco com base no ID fornecido e retorna um objeto BancoModels
    public BancoModels findById(int id) throws SQLException {

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        BancoModels retorno = null;

        try {
            // Abre uma conexão com o banco de dados
            conn = new DataBase().getConnection();

            // Prepara uma declaração SQL para buscar uma linha na tabela Banco com base no ID fornecido
            pstmt = conn.prepareStatement(FIND_BY_ID);
            pstmt.setInt(1, id);

            // Executa a declaração SQL e armazena o resultado em um objeto ResultSet
            rs = pstmt.executeQuery();

            // Se um resultado for encontrado, cria um objeto BancoModels e preenche com os dados da linha
            while (rs.next()) {
                retorno = new BancoModels();
                retorno.setId(rs.getInt("ID"));
                retorno.setNome(rs.getString("NOME"));
                retorno.setRa(rs.getString("RA"));
            }
        } finally {
            // Fecha o ResultSet, PreparedStatement e Connection, caso não tenham sido fechados ainda
            if (rs != null) {
                rs.close();
            }
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

        // Retorna o objeto BancoModels encontrado, ou null se não houver resultados
        return retorno;
    }

    // Insere uma nova linha na tabela Banco com base nos dados fornecidos em um objeto BancoModels
    public void insert(BancoModels banco) throws SQLException {

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // Abre uma conexão com o banco de dados
            conn = new DataBase().getConnection();

            // Prepara uma declaração SQL para inserir uma nova linha na tabela Banco com base nos dados do objeto BancoModels fornecido
            pstmt = conn.prepareStatement(INSERT);
            pstmt.setInt(1, banco.getId());
            pstmt.setString(2, banco.getNome());
            pstmt.setString(3, banco.getRa());

            // Executa a declaração SQL para inserir a nova linha            pstmt.executeUpdate();

        } finally {
            // Fecha o PreparedStatement e Connection, caso não tenham sido fechados ainda
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

    }

    // Atualiza uma linha existente na tabela Banco com base nos dados fornecidos em um objeto BancoModels
    public void update(BancoModels banco) throws SQLException {

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // Abre uma conexão com o banco de dados
            conn = new DataBase().getConnection();

            // Prepara uma declaração SQL para atualizar uma linha na tabela Banco com base nos dados do objeto BancoModels fornecido
            pstmt = conn.prepareStatement(UPDATE);
            pstmt.setString(1, banco.getNome());
            pstmt.setString(2, banco.getRa());
            pstmt.setInt(3, banco.getId());

            // Executa a declaração SQL para atualizar a linha
            pstmt.executeUpdate();

        } finally {
            // Fecha o PreparedStatement e Connection, caso não tenham sido fechados ainda
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

    }

    // Remove uma linha da tabela Banco com base no ID fornecido
    public void delete(int id) throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // Abre uma conexão com o banco de dados
            conn = new DataBase().getConnection();

            // Prepara uma declaração SQL para remover uma linha da tabela Banco com base no ID fornecido
            pstmt = conn.prepareStatement(DELETE_BY_ID);
            pstmt.setInt(1, id);

            // Executa a declaração SQL para remover a linha
            pstmt.executeUpdate();

        } finally {
            // Fecha o PreparedStatement e Connection, caso não tenham sido fechados ainda
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
    }
}