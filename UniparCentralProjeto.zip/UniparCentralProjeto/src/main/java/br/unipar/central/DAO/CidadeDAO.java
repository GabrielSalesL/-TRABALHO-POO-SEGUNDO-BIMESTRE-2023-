package br.unipar.central.DAO;

import br.unipar.central.models.CidadeModels;
import br.unipar.central.models.EstadoModels;

import br.unipar.central.util.DataBase;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CidadeDAO {

    // Declara as consultas SQL como constantes para evitar erros de digitação
    private static final String INSERT = "INSERT INTO cidade(id, nome, ra, estado_id) VALUES(?, ?, ?, ?)";
    private static final String FIND_ALL = "SELECT id, nome, ra, estado_id FROM cidade";
    private static final String FIND_BY_ID = "SELECT id, nome, ra, estado_id FROM cidade WHERE id = ?";
    private static final String DELETE_BY_ID = "DELETE FROM cidade WHERE id = ?";
    private static final String UPDATE = "UPDATE cidade SET nome = ?, RA = ?, estado_id = ? WHERE ID = ?";

    // Busca todas as linhas na tabela Cidade e retorna uma lista de objetos CidadeModels
    public List<CidadeModels> findAll() throws SQLException {
        ArrayList<CidadeModels> retorno = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            // Abre uma conexão com o banco de dados
            conn = new DataBase().getConnection();

            // Prepara uma declaração SQL para buscar todas as linhas na tabela Cidade
            pstmt = conn.prepareStatement(FIND_ALL);

            // Executa a declaração SQL e armazena o resultado em um objeto ResultSet
            rs = pstmt.executeQuery();

            // Itera sobre o ResultSet e adiciona cada linha como um objeto CidadeModels na lista de retorno
            while (rs.next()) {
                CidadeModels cidade = new CidadeModels();
                cidade.setId(rs.getInt("id"));
                cidade.setNome(rs.getString("nome"));
                cidade.setRa(rs.getString("ra"));
                cidade.setEstado(new EstadoDAO().findById(rs.getInt("estado_id"))); // realiza uma busca pelo objeto EstadoModels correspondente ao ID da cidade
                retorno.add(cidade);
            }
        } finally {
            // Fecha o ResultSet, PreparedStatement e Connection, caso não tenham sido fechados ainda
            if (rs != null) {
                rs.close();
            }
            if (conn != null) {
                conn.close();
            }
            if (pstmt != null) {
                pstmt.close();
            }
        }

        // Retorna a lista de objetos CidadeModels
        return retorno;
    }

    // Busca uma única linha na tabela Cidade com base no ID fornecido e retorna um objeto CidadeModels
    public CidadeModels findById(int id) throws SQLException {

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        CidadeModels retorno = null;

        try {
            // Abre uma conexão com o banco de dados
            conn = new DataBase().getConnection();

            // Prepara uma declaração SQL para buscar uma linha na tabela Cidade com base no ID fornecido
            pstmt = conn.prepareStatement(FIND_BY_ID);
            pstmt.setInt(1, id);

            // Executa a declaração SQL e armazena o resultado em um objeto ResultSet
            rs = pstmt.executeQuery();

            // Se um resultado for encontrado, cria um objeto CidadeModels e preenche com os dados da linha
            while (rs.next()) {
                retorno = new CidadeModels();
                retorno.setId(rs.getInt("id"));
                retorno.setNome(rs.getString("nome"));
                retorno.setRa(rs.getString("ra"));
                retorno.setEstado(new EstadoDAO().findById(rs.getInt("estado_id"))); // realiza uma busca pelo objeto EstadoModels correspondente ao ID da cidade
            }
        } finally {
            // Fecha o ResultSet, PreparedStatement e Connection, caso não tenham sido fechados ainda
            if (rs != null) {
                rs.close();
            }
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

        // Retorna o objeto CidadeModels encontrado, ou null se não houver resultados
        return retorno;
    }

    // Insere uma nova linha na tabela Cidade com base nos dados fornecidos em um objeto CidadeModels
    public void insert(CidadeModels cidade) throws SQLException {

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // Abre uma conexão com o banco de dadosconn = new DataBase().getConnection();
            pstmt = conn.prepareStatement(INSERT);

            // Define os valores dos parâmetros da declaração SQL com base nos dados do objeto CidadeModels fornecido
            pstmt.setInt(1, cidade.getId());
            pstmt.setString(2, cidade.getNome());
            pstmt.setString(3, cidade.getRa());
            pstmt.setInt(4, cidade.getEstado().getId()); // insere o ID do objeto EstadoModels correspondente

            // Executa a declaração SQL de inserção
            pstmt.executeUpdate();

        } finally {
            // Fecha o PreparedStatement e Connection, caso não tenham sido fechados ainda
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

    }

    // Atualiza uma linha na tabela Cidade com base nos dados fornecidos em um objeto CidadeModels
    public void update(CidadeModels cidade) throws SQLException {

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // Abre uma conexão com o banco de dados
            conn = new DataBase().getConnection();
            pstmt = conn.prepareStatement(UPDATE);

            // Define os valores dos parâmetros da declaração SQL com base nos dados do objeto CidadeModels fornecido
            pstmt.setString(1, cidade.getNome());
            pstmt.setString(2, cidade.getRa());
            pstmt.setInt(3, cidade.getEstado().getId()); // insere o ID do objeto EstadoModels correspondente
            pstmt.setInt(4, cidade.getId()); // atualiza a linha com base no ID fornecido

            // Executa a declaração SQL de atualização
            pstmt.executeUpdate();

        } finally {
            // Fecha o PreparedStatement e Connection, caso não tenham sido fechados ainda
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

    }

    // Deleta uma linha na tabela Cidade com base no ID fornecido
    public void delete(int id) throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // Abre uma conexão com o banco de dados
            conn = new DataBase().getConnection();
            pstmt = conn.prepareStatement(DELETE_BY_ID);

            // Define o valor do parâmetro da declaração SQL com base no ID fornecido
            pstmt.setInt(1, id);

            // Executa a declaração SQL de exclusão
            pstmt.executeUpdate();

        } finally {
            // Fecha o PreparedStatement e Connection, caso não tenham sido fechados ainda
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
    }
}