package br.unipar.central.DAO;

import br.unipar.central.enums.TipoContaEnum;
import br.unipar.central.models.ContaModels;
import br.unipar.central.util.DataBase;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ContaDAO {

    // Constantes para as queries SQL
    private static final String INSERT = "INSERT INTO conta(id, numero, digito, saldo, tipo, ra, agencia_id, pessoa_id) VALUES(?, ?, ?, ?, ?::INTEGER, ?, ?, ?)";
    private static final String FIND_ALL = "SELECT id, numero, digito, saldo, tipo, ra, agencia_id, pessoa_id FROM conta ";
    private static final String FIND_BY_ID = "SELECT id, numero, digito, saldo, tipo, ra, agencia_id, pessoa_id FROM conta WHERE id = ? ";
    private static final String DELETE_BY_ID = "DELETE FROM conta WHERE id = ?";
    private static final String UPDATE = "UPDATE conta SET  numero = ?, digito = ?, saldo = ?, tipo = ?, ra = ?, agencia_id = ?, pessoa_id = ? WHERE id = ?";

    /**
     * Busca todas as contas cadastradas no banco de dados.
     *
     * @return uma lista de objetos ContaModels representando as contas encontradas.
     * @throws SQLException em caso de erro na comunicação com o banco de dados.
     */
    public List<ContaModels> findAll() throws SQLException {
        ArrayList<ContaModels> retorno = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = new DataBase().getConnection();

            pstmt = conn.prepareStatement(FIND_ALL);

            rs = pstmt.executeQuery();

            while (rs.next()) {
                ContaModels conta = new ContaModels();
                conta.setId(rs.getInt("id"));
                conta.setNumero(rs.getString("numero"));
                conta.setDigito(rs.getString("digito"));
                conta.setSaldo(Double.parseDouble(rs.getString("saldo")));
                conta.setTipoConta(TipoContaEnum.paraEnum(rs.getInt("tipo")));
                conta.setRa(rs.getString("ra"));
                conta.setAgencia(new AgenciaDAO().findById(rs.getInt("agencia_id")));
                conta.setPessoa(new PessoaDAO().findById(rs.getInt("pessoa_id")));

                retorno.add(conta);
            }
        } finally {
            // Fecha as conexões e libera recursos
            if (conn != null) {
                conn.close();
            }

            if (conn != null) {
                pstmt.close();
            }
        }

        return retorno;
    }

    /**
     * Busca uma conta específica pelo ID.
     *
     * @param id o ID da conta a ser buscada.
     * @return uma instância de ContaModels representando a conta encontrada.
     * @throws SQLException em caso de erro na comunicação com o banco de dados.
     */
    public ContaModels findById(int id) throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        ContaModels retorno = null;

        try {
            conn = new DataBase().getConnection();

            pstmt = conn.prepareStatement(FIND_BY_ID);

            pstmt.setInt(1, id);

            rs = pstmt.executeQuery();

            while (rs.next()) {
                retorno = new ContaModels();
                retorno.setId(rs.getInt("id"));
                retorno.setNumero(rs.getString("numero"));
                retorno.setDigito(rs.getString("digito"));
                retorno.setSaldo(Double.parseDouble(rs.getString("saldo")));
                retorno.setTipoConta(TipoContaEnum.paraEnum(rs.getInt("tipo")));
                retorno.setRa(rs.getString("ra"));
                retorno.setAgencia(new AgenciaDAO().findById(rs.getInt("agencia_id")));
                retorno.setPessoa(new PessoaDAO().findById(rs.getInt("pessoa_id")));

            }
        } finally {
            // Fecha as conexões e libera recursos
            if (rs != null) {
                rs.close();
            }

            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        return retorno;
    }

    /**
     * Insere uma nova conta no banco de dados.
     *
     * @param conta a conta a ser inserida.
     * @throws SQLException em caso de erro na comunicação com o banco de dados.
     */
    public void insert(ContaModels conta) throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = new DataBase().getConnection();
            pstmt = conn.prepareStatement(INSERT);

            pstmt.setInt(1, conta.getId());
            pstmt.setString(2, conta.getNumero());
            pstmt.setString(3, conta.getDigito());
            pstmt.setDouble(4, conta.getSaldo());
            pstmt.setInt(5, mapearTipoConta(conta.getTipoConta()));
            pstmt.setString(6, conta.getRa());
            pstmt.setInt(7, conta.getAgencia().getId());
            pstmt.setInt(8, conta.getPessoa().getId());

            pstmt.executeUpdate();
        } finally {
            // Fecha as conexões e libera recursos
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

    }

    /**
     * Atualiza uma conta existente no banco de dados.
     *
     * @param conta a conta a ser atualizada.
     * @throws SQLException em caso de erro na comunicação com o banco de dados.
     */
    public void update(ContaModels conta) throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = new DataBase().getConnection();
            pstmt = conn.prepareStatement(UPDATE);

            pstmt.setString(1, conta.getNumero());
            pstmt.setString(2, conta.getDigito());
            pstmt.setDouble(3, conta.getSaldo());
            pstmt.setInt(4, mapearTipoConta(conta.getTipoConta()));
            pstmt.setString(5, conta.getRa());
            pstmt.setInt(6, conta.getAgencia().getId());
            pstmt.setInt(7, conta.getPessoa().getId());
            pstmt.setInt(8, conta.getId());

            pstmt.executeUpdate();

        } finally {
            // Fecha as conexões e libera recursos
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

    }

    /**
     * Deleta uma conta existente no banco de dados pelo ID.
     *
     * @param id o ID da conta a ser deletada.
     * @throws SQLException em caso de erro na comunicação com o banco de dados.
     */
    public void delete(int id) throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = new DataBase().getConnection();
            pstmt = conn.prepareStatement(DELETE_BY_ID);

            pstmt.setInt(1, id);

            pstmt.executeUpdate();

        } finally {
            // Fecha as conexões e libera recursos
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
    }

    /**
     * Converte um objeto TipoContaEnum para um número inteiro.
     * 
     * @param tipoConta o tipo de conta a ser convertido.
     * @return o número inteiro correspondente ao tipo de conta.
     */
    private int mapearTipoConta(TipoContaEnum tipoConta) {
        if (tipoConta == TipoContaEnum.CORRENTE) {
            return 1;
        } else if (tipoConta == TipoContaEnum.POUPANCA) {
            return 2;
        } else if (tipoConta == TipoContaEnum.SALARIO) {
            return 3;
        } else {
            throw new IllegalArgumentException("Tipo de conta inválida!! " + tipoConta);
        }
    }

}