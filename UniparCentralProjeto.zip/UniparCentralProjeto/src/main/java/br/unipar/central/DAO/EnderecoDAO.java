package br.unipar.central.DAO;

import br.unipar.central.enums.TipoContaEnum;
import br.unipar.central.models.ContaModels;
import br.unipar.central.models.EnderecoModels;
import br.unipar.central.util.DataBase;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EnderecoDAO {

    // Declarações SQL
    private static final String INSERT = "INSERT INTO endereco(id, logradouro, numero, bairro, cep, complemento, ra, pessoa_id, cidade_id) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
    private static final String FIND_ALL = "SELECT id, logradouro, numero, bairro, cep, complemento, ra, pessoa_id, cidade_id FROM endereco ";
    private static final String FIND_BY_ID = "SELECT id, logradouro, numero, bairro, cep, complemento, ra, pessoa_id, cidade_id FROM endereco WHERE id = ? ";
    private static final String DELETE_BY_ID = "DELETE FROM endereco WHERE id = ?";
    private static final String UPDATE = "UPDATE endereco SET logradouro = ?, numero = ?, bairro = ?, cep = ?, complemento = ?, ra = ?, pessoa_id = ?, cidade_id = ? WHERE id = ?";

    // Método para buscar todos os endereços
    public List<EnderecoModels> findAll() throws SQLException {
        ArrayList<EnderecoModels> retorno = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            // Obter uma conexão com o banco de dados
            conn = new DataBase().getConnection();

            // Criar uma instrução preparada para a consulta SQL
            pstmt = conn.prepareStatement(FIND_ALL);

            // Executar a consulta e obter o conjunto de resultados
            rs = pstmt.executeQuery();

            // Percorrer o conjunto de resultados e criar objetos EnderecoModels
            while (rs.next()) {
                EnderecoModels endereco = new EnderecoModels();
                endereco.setId(rs.getInt("id"));
                endereco.setLogradouro(rs.getString("logradouro"));
                endereco.setNumero(rs.getString("numero"));
                endereco.setBairro(rs.getString("bairro"));
                endereco.setCep(rs.getString("cep"));
                endereco.setRa(rs.getString("ra"));
                endereco.setComplemento(rs.getString("complemento"));
                endereco.setRa(rs.getString("ra"));
                endereco.setCidade(new CidadeDAO().findById(rs.getInt("cidade_id")));
                endereco.setPessoa(new PessoaDAO().findById(rs.getInt("pessoa_id")));

                // Adicionar o objeto EnderecoModels à lista de resultados
                retorno.add(endereco);
            }
        } finally {
            // Fechar os recursos do banco de dados
            if (conn != null) {
                conn.close();
            }

            if (conn != null) {
                pstmt.close();
            }
        }

        // Retornar a lista de objetos EnderecoModels
        return retorno;
    }

    // Método para buscar um endereço pelo ID
    public EnderecoModels findById(int id) throws SQLException {

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        EnderecoModels retorno = null;

        try {
            // Obter uma conexão com o banco de dados
            conn = new DataBase().getConnection();

            // Criar uma instrução preparada para a consulta SQL
            pstmt = conn.prepareStatement(FIND_BY_ID);

            // Definir o parâmetro ID para a consulta
            pstmt.setInt(1, id);

            // Executar a consulta e obter o conjunto de resultados
            rs = pstmt.executeQuery();

            // Percorrer o conjunto de resultados e criar um objeto EnderecoModels
            while (rs.next()) {
                retorno = new EnderecoModels();
                retorno.setId(rs.getInt("id"));
                retorno.setLogradouro(rs.getString("logradouro"));
                retorno.setNumero(rs.getString("numero"));
                retorno.setBairro(rs.getString("bairro"));
                retorno.setCep(rs.getString("cep"));
                retorno.setRa(rs.getString("ra"));
                retorno.setComplemento(rs.getString("complemento"));
                retorno.setRa(rs.getString("ra"));
                retorno.setCidade(new CidadeDAO().findById(rs.getInt("cidade_id")));
                retorno.setPessoa(new PessoaDAO().findById(rs.getInt("pessoa_id")));

            }
        } finally {
            // Fechar os recursos do banco de dados
            if (rs != null) {
                rs.close();
            }

            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

        // Retornar o objeto EnderecoModels
        return retorno;
    }

    // Método para inserir um novo endereço
    public void insert(EnderecoModels endereco) throws SQLException {

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // Obter uma conexão com o banco de dados
            conn = new DataBase().getConnection();

            // Criar uma instrução preparada para a inserção SQL
            pstmt = conn.prepareStatement(INSERT);

            // Definir os parâmetros da instrução preparada
            pstmt.setInt(1, endereco.getId());
            pstmt.setString(2, endereco.getLogradouro());
            pstmt.setString(3, endereco.getNumero());
            pstmt.setString(4, endereco.getBairro());
            pstmt.setString(5, endereco.getCep());
            pstmt.setString(6, endereco.getComplemento());
            pstmt.setString(7, endereco.getRa());
            pstmt.setInt(8, endereco.getPessoa().getId());
            pstmt.setInt(9, endereco.getCidade().getId());

            // Executar a instrução preparada
            pstmt.executeUpdate();
        } finally {
            // Fechar os recursos do banco de dados
            if (pstmt != null) {
                pstmt.close();
            }

            if (conn != null) {
                conn.close();
            }
        }
    }

    // Método para atualizar um endereço existente
    public void update(EnderecoModels endereco) throws SQLException {

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // Obter uma conexão com o banco de dados
            conn = new DataBase().getConnection();

            // Criar uma instrução preparada para a atualização SQL
            pstmt = conn.prepareStatement(UPDATE);

            // Definir os parâmetros da instrução preparada
            pstmt.setString(1, endereco.getLogradouro());
            pstmt.setString(2, endereco.getNumero());
            pstmt.setString(3, endereco.getBairro());
            pstmt.setString(4, endereco.getCep());
            pstmt.setString(5, endereco.getComplemento());
            pstmt.setString(6, endereco.getRa());
            pstmt.setInt(7, endereco.getPessoa().getId());
            pstmt.setInt(8, endereco.getCidade().getId());
            pstmt.setInt(9, endereco.getId());

            // Executar a instrução preparada
            pstmt.executeUpdate();
        } finally {
            // Fechar os recursos do banco de dados
            if (pstmt != null) {
                pstmt.close();
            }

            if (conn != null) {
                conn.close();
            }
        }
    }

    // Método para excluir um endereço pelo ID
    public void deleteById(int id) throws SQLException {

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // Obter uma conexão com o banco de dados
            conn = new DataBase().getConnection();

            // Criar uma instrução preparada para a exclusão SQL
            pstmt = conn.prepareStatement(DELETE_BY_ID);

            // Definir o parâmetro ID da instrução preparada
            pstmt.setInt(1, id);

            // Executar a instrução preparada
            pstmt.executeUpdate();
        } finally {
            // Fechar os recursos do banco de dados
            if (pstmt != null) {
                pstmt.close();
            }

            if (conn != null) {
                conn.close();
            }
        }
    }

    public void delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}