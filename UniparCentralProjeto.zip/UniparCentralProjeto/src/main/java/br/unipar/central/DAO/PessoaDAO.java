package br.unipar.central.DAO;

import br.unipar.central.models.PessoaModels;
import br.unipar.central.util.DataBase;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PessoaDAO {

    // Declaração das constantes para as operações SQL
    private static final String INSERT = "INSERT INTO pessoa(id, email, ra) VALUES(?, ?, ?)";
    private static final String FIND_ALL = "SELECT id, email, ra FROM pessoa";
    private static final String FIND_BY_ID = "SELECT id, email, ra FROM pessoa WHERE id = ?";
    private static final String DELETE_BY_ID = "DELETE FROM pessoa WHERE id = ?";
    private static final String UPDATE = "UPDATE pessoa SET email = ?, ra = ? WHERE id = ?";

// Método para buscar todas as pessoas cadastradas no banco de dados
    public List<PessoaModels> findAll() throws SQLException {
        ArrayList<PessoaModels> retorno = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = new DataBase().getConnection();
            pstmt = conn.prepareStatement(FIND_ALL);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                PessoaModels pessoa = new PessoaModels();
                pessoa.setId(rs.getInt("id"));
                pessoa.setEmail(rs.getString("email"));
                pessoa.setRa(rs.getString("ra"));
                retorno.add(pessoa);
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (conn != null) {
                conn.close();
            }
            if (pstmt != null) {
                pstmt.close();
            }
        }

        return retorno;
    }

// Método para buscar uma pessoa específica pelo seu ID
    public PessoaModels findById(int id) throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        PessoaModels retorno = null;

        try {
            conn = new DataBase().getConnection();
            pstmt = conn.prepareStatement(FIND_BY_ID);
            pstmt.setInt(1, id);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                retorno = new PessoaModels();
                retorno.setId(rs.getInt("id"));
                retorno.setEmail(rs.getString("email"));
                retorno.setRa(rs.getString("ra"));
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        return retorno;
    }

// Método para inserir uma nova pessoa no banco de dados
    public void insert(PessoaModels pessoa) throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = new DataBase().getConnection();
            pstmt = conn.prepareStatement(INSERT);

            pstmt.setInt(1, pessoa.getId());
            pstmt.setString(2, pessoa.getEmail());
            pstmt.setString(3, pessoa.getRa());

            pstmt.executeUpdate();
        } finally {
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
    }

// Método para atualizar uma pessoa existente no banco de dados
    public void update(PessoaModels pessoa) throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = new DataBase().getConnection();
            pstmt = conn.prepareStatement(UPDATE);

            pstmt.setString(1, pessoa.getEmail());
            pstmt.setString(2, pessoa.getRa());
            pstmt.setInt(3, pessoa.getId());

            pstmt.executeUpdate();
        } finally {
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
    }

// Método para excluir uma pessoa do banco de dados pelo seu ID
    public void delete(int id) throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = new DataBase().getConnection();
            pstmt = conn.prepareStatement(DELETE_BY_ID);

            pstmt.setInt(1, id);

            pstmt.executeUpdate();
        } finally {
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
    }
}
