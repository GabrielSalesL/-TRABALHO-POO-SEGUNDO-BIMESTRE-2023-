package br.unipar.central.DAO;

import br.unipar.central.models.PessoaFisicaModels;
import br.unipar.central.util.DataBase;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PessoaFisicaDAO {

    // Declaração das constantes para as operações SQL
    private static final String INSERT = "INSERT INTO pessoafisica(nome, cpf, rg, datanascimento, pessoa_id) VALUES(?, ?, ?, ?, ?)";
    private static final String FIND_ALL = "SELECT nome, cpf, rg, datanascimento, pessoa_id FROM pessoafisica ";
    private static final String FIND_BY_ID = "SELECT nome, cpf, rg, datanascimento, pessoa_id FROM pessoafisica WHERE cpf = ? ";
    private static final String DELETE_BY_ID = "DELETE FROM pessoafisica WHERE cpf = ?";
    private static final String UPDATE = "UPDATE pessoafisica SET nome = ?, rg = ?, datanascimento = ?, pessoa_id = ? WHERE cpf = ?";

// Método para buscar todas as pessoas físicas cadastradas no banco de dados
    public List<PessoaFisicaModels> findAll() throws SQLException {
        ArrayList<PessoaFisicaModels> retorno = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = new DataBase().getConnection();
            pstmt = conn.prepareStatement(FIND_ALL);
            rs = pstmt.executeQuery();

            // Laço para percorrer os resultados da consulta e criar uma lista de pessoas físicas
            while (rs.next()) {
                PessoaFisicaModels pessoaFisica = new PessoaFisicaModels();
                pessoaFisica.setNome(rs.getString("nome"));
                pessoaFisica.setCpf(rs.getString("cpf"));
                pessoaFisica.setRg(rs.getString("rg"));
                pessoaFisica.setDataNascimento(Date.valueOf(rs.getString("datanascimento")));
                pessoaFisica.setPessoa(new PessoaDAO().findById(rs.getInt("pessoa_id")));
                retorno.add(pessoaFisica);
            }
        } finally {
            // Bloco finally para garantir que os recursos são liberados corretamente
            if (rs != null) {
                rs.close();
            }
            if (conn != null) {
                conn.close();
            }
            if (pstmt != null) {
                pstmt.close();
            }
        }

        return retorno;
    }

// Método para buscar uma pessoa física específica pelo seu CPF
    public PessoaFisicaModels findById(String cpf) throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        PessoaFisicaModels retorno = null;

        try {
            conn = new DataBase().getConnection();
            pstmt = conn.prepareStatement(FIND_BY_ID);
            pstmt.setString(1, cpf);
            rs = pstmt.executeQuery();

            // Laço para percorrer os resultados da consulta e criar uma pessoa física
            while (rs.next()) {
                retorno = new PessoaFisicaModels();
                retorno.setNome(rs.getString("nome"));
                retorno.setCpf(rs.getString("cpf"));
                retorno.setRg(rs.getString("rg"));
                retorno.setDataNascimento(Date.valueOf(rs.getString("datanascimento")));
                retorno.setPessoa(new PessoaDAO().findById(rs.getInt("pessoa_id")));
            }
        } finally {
            // Bloco finally para garantir que os recursos são liberados corretamente
            if (rs != null) {
                rs.close();
            }
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        return retorno;
    }

// Método para inserir uma nova pessoa física no banco de dados
    public void insert(PessoaFisicaModels pessoaFisica) throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = new DataBase().getConnection();
            pstmt = conn.prepareStatement(INSERT);

            pstmt.setString(1, pessoaFisica.getNome());
            pstmt.setString(2, pessoaFisica.getCpf());
            pstmt.setString(3, pessoaFisica.getRg());
            pstmt.setDate(4, Date.valueOf(pessoaFisica.getDataNascimento().toString()));
            pstmt.setInt(5, pessoaFisica.getPessoa().getId());

            pstmt.executeUpdate();
        } finally {
            // Bloco finally para garantir que os recursos são liberados corretamente
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
    }

    public void update(PessoaFisicaModels pessoaFisica) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void delete(String cpf) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
