package br.unipar.central.DAO;

import br.unipar.central.models.PessoaJuridicaModels;
import br.unipar.central.util.DataBase;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PessoaJuridicaDAO {

    // Consulta SQL para inserir uma nova pessoa jurídica na tabela 'pessoajuridica'
    private static final String INSERT = "INSERT INTO pessoajuridica(razaosocial, cnpj, cnaeprincipal, fantasia, pessoa_id) VALUES(?, ?, ?, ?, ?)";

    // Consulta SQL para buscar todas as pessoas jurídicas cadastradas na tabela 'pessoajuridica'
    private static final String FIND_ALL = "SELECT razaosocial, cnpj, cnaeprincipal, fantasia, pessoa_id FROM pessoajuridica ";

    // Consulta SQL para buscar uma pessoa jurídica específica na tabela 'pessoajuridica', com base no seu CNPJ
    private static final String FIND_BY_ID = "SELECT razaosocial, cnpj, cnaeprincipal, fantasia, pessoa_id FROM pessoajuridica WHERE cnpj = ? ";

    // Consulta SQL para excluir uma pessoa jurídica da tabela 'pessoajuridica', com base no seu CNPJ
    private static final String DELETE_BY_ID = "DELETE FROM pessoajuridica WHERE cnpj = ?";

    // Consulta SQL para atualizar os dados de uma pessoa jurídica na tabela 'pessoajuridica', com base no seu CNPJ
    private static final String UPDATE = "UPDATE pessoajuridica SET razaosocial = ?, cnaeprincipal = ?, fantasia = ?, pessoa_id = ? WHERE cnpj = ?";

    // Método para buscar todas as pessoas jurídicas cadastradas na tabela 'pessoajuridica'
    public List<PessoaJuridicaModels> findAll() throws SQLException {
        ArrayList<PessoaJuridicaModels> retorno = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {

            // Obtém uma conexão com o banco de dados
            conn = new DataBase().getConnection();

            // Cria um PreparedStatement com a consulta SQL para buscar todas as pessoas jurídicas
            pstmt = conn.prepareStatement(FIND_ALL);

            // Executa a consulta SQL e obtém um ResultSet com os resultados
            rs = pstmt.executeQuery();

            // Percorre o ResultSet e cria um objeto PessoaJuridicaModels para cada registro
            while (rs.next()) {
                PessoaJuridicaModels pessoaJuridica = new PessoaJuridicaModels();
                pessoaJuridica.setRazaoSocial(rs.getString("razaosocial"));
                pessoaJuridica.setNomeFantasia(rs.getString("fantasia"));
                pessoaJuridica.setCNPJ(rs.getString("cnpj"));
                pessoaJuridica.setCnaePrincipal(rs.getString("cnaeprincipal"));
                pessoaJuridica.setPessoa(new PessoaDAO().findById(rs.getInt("pessoa_id")));
                retorno.add(pessoaJuridica);
            }
        } finally {

            // Fecha os objetos ResultSet, PreparedStatement e Connection
            if (rs != null) {
                rs.close();
            }

            if (conn != null) {
                conn.close();
            }

            if (pstmt != null) {
                pstmt.close();
            }
        }

        // Retorna a lista de objetos PessoaJuridicaModels
        return retorno;
    }

    // Método para buscar uma pessoa jurídica na tabela 'pessoajuridica', com base no seu CNPJ
    public PessoaJuridicaModels findById(String cnpj) throws SQLException {

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        PessoaJuridicaModels retorno = null;

        try {

            // Obtém uma conexão com o banco de dados
            conn = new DataBase().getConnection();

            // Cria um PreparedStatement com a consulta SQL para buscar a pessoa jurídica com o CNPJ especificado
            pstmt = conn.prepareStatement(FIND_BY_ID);

            // Define o parâmetro da consulta (o CNPJ)
            pstmt.setString(1, cnpj);

            // Executa a consulta SQL e obtém um ResultSet com os resultados
            rs = pstmt.executeQuery();

            // Cria um objeto PessoaJuridicaModels com os dados da primeira (e única) linha do ResultSet
            while (rs.next()) {
                retorno = new PessoaJuridicaModels();
                retorno.setRazaoSocial(rs.getString("razaosocial"));
                retorno.setNomeFantasia(rs.getString("fantasia"));
                retorno.setCNPJ(rs.getString("cnpj"));
                retorno.setCnaePrincipal(rs.getString("cnaeprincipal"));
                retorno.setPessoa(new PessoaDAO().findById(rs.getInt("pessoa_id")));
            }
        } finally {

            // Fecha os objetos ResultSet, PreparedStatement e Connection
            if (rs != null) {
                rs.close();
            }

            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

        // Retorna o objeto PessoaJuridicaModels encontrado (ou null, se não houver nenhum registro com o CNPJ especificado)
        return retorno;
    }

    // Método para inserir uma nova pessoa jurídica na tabela 'pessoajuridica'
    public void insert(PessoaJuridicaModels pessoaJuridica) throws SQLException {

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {

            // Obtém uma conexão com o banco de dados
            conn = new DataBase().getConnection();

            // Cria um PreparedStatement com a consulta SQL para inserir a nova pessoa jurídica
            pstmt = conn.prepareStatement(INSERT);

            // Define os parâmetros da consulta (os dados da pessoa jurídica)
            pstmt.setString(1, pessoaJuridica.getRazaoSocial());
            pstmt.setString(2, pessoaJuridica.getCNPJ());
            pstmt.setString(3, pessoaJuridica.getCnaePrincipal());
            pstmt.setString(4, pessoaJuridica.getNomeFantasia());
            pstmt.setInt(5, pessoaJuridica.getPessoa().getId());

            // Executa a consulta SQL de inserção
            pstmt.executeUpdate();
        } finally {

            // Fecha os objetos PreparedStatement e Connection
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

    }

    // Método para atualizar os dados de uma pessoa jurídica na tabela 'pessoajuridica', com base no seu CNPJ
    public void update(PessoaJuridicaModels pessoaJuridica) throws SQLException {

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {

            // Obtém uma conexão com o banco de dados
            conn = new DataBase().getConnection();

            // Cria um PreparedStatement com a consulta SQL para atualizar os dados da pessoa jurídica
            pstmt = conn.prepareStatement(UPDATE);

            // Define os parâmetros da consulta (os novos dados da pessoa jurídica e o CNPJ dela)
            pstmt.setString(1, pessoaJuridica.getRazaoSocial());
            pstmt.setString(2, pessoaJuridica.getCnaePrincipal());
            pstmt.setString(3, pessoaJuridica.getNomeFantasia());
            pstmt.setInt(4, pessoaJuridica.getPessoa().getId());
            pstmt.setString(5, pessoaJuridica.getCNPJ());

            // Executa a consulta SQL de atualização
            pstmt.executeUpdate();

        } finally {

            // Fecha os objetos PreparedStatement e Connection
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

    }

    // Método para excluir uma pessoa jurídica da tabela 'pessoajuridica', com base no seu CNPJ
    public void delete(String cnpj) throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {

            // Obtém uma conexão com o banco de dados
            conn = new DataBase().getConnection();

            // Cria um PreparedStatement com a consulta SQL para excluir a pessoa jurídica com o CNPJ especificado
            pstmt = conn.prepareStatement(DELETE_BY_ID);

            // Define o parâmetro da consulta (o CNPJ)
            pstmt.setString(1, cnpj);

            // Executa a consulta SQL de exclusão
            pstmt.executeUpdate();

        } finally {

            // Fecha os objetos PreparedStatement e Connection
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
    }
}