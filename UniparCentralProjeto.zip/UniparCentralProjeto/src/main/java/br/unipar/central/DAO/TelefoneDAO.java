package br.unipar.central.DAO;

import br.unipar.central.enums.TipoContaEnum;
import br.unipar.central.enums.TipoOperadoraEnum;
import br.unipar.central.models.ContaModels;
import br.unipar.central.models.TelefoneModels;
import br.unipar.central.util.DataBase;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TelefoneDAO {

    // Query SQL para inserir um telefone na tabela
    private static final String INSERT = "INSERT INTO telefone(id, numero, operadora, ra, agencia_id, pessoa_id) VALUES(?, ?, ?::INTEGER, ?, ?, ?)";

    // Query SQL para buscar todos os telefones na tabela
    private static final String FIND_ALL = "SELECT id, numero, operadora, ra, agencia_id, pessoa_id FROM telefone ";

    // Query SQL para buscar um telefone na tabela pelo ID
    private static final String FIND_BY_ID = "SELECT id, numero, operadora, ra, agencia_id, pessoa_id FROM telefone WHERE id = ? ";

    // Query SQL para deletar um telefone na tabela pelo ID
    private static final String DELETE_BY_ID = "DELETE FROM telefone WHERE id = ?";

    // Query SQL para atualizar um telefone na tabela pelo ID
    private static final String UPDATE = "UPDATE telefone SET  numero = ?, operadora = ?, ra = ?, agencia_id = ?, pessoa_id = ? WHERE id = ?";

    // Método para buscar todos os telefones na tabela
    public List<TelefoneModels> findAll() throws SQLException {
        ArrayList<TelefoneModels> retorno = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {

            conn = new DataBase().getConnection();

            pstmt = conn.prepareStatement(FIND_ALL);

            rs = pstmt.executeQuery();

            while (rs.next()) {
                TelefoneModels telefone = new TelefoneModels();
                telefone.setId(rs.getInt("id"));
                telefone.setNumero(rs.getString("numero"));
                telefone.setOperadora(TipoOperadoraEnum.paraEnum(rs.getInt("operadora")));
                telefone.setRa(rs.getString("ra"));
                telefone.setAgencia(new AgenciaDAO().findById(rs.getInt("agencia_id")));
                telefone.setPessoa(new PessoaDAO().findById(rs.getInt("pessoa_id")));
                retorno.add(telefone);
            }
        } finally {

            // Fecha a conexão com o banco de dados e o PreparedStatement
            if (conn != null) {
                conn.close();
            }

            if (conn != null) {
                pstmt.close();
            }
        }

        return retorno;
    }

    // Método para buscar um telefone na tabela pelo ID
    public TelefoneModels findById(int id) throws SQLException {

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        TelefoneModels retorno = null;

        try {
            conn = new DataBase().getConnection();

            pstmt = conn.prepareStatement(FIND_BY_ID);

            pstmt.setInt(1, id);

            rs = pstmt.executeQuery();

            while (rs.next()) {
                retorno = new TelefoneModels();
                retorno.setId(rs.getInt("id"));
                retorno.setNumero(rs.getString("numero"));
                retorno.setOperadora(TipoOperadoraEnum.paraEnum(rs.getInt("operadora")));
                retorno.setRa(rs.getString("ra"));
                retorno.setAgencia(new AgenciaDAO().findById(rs.getInt("agencia_id")));
                retorno.setPessoa(new PessoaDAO().findById(rs.getInt("pessoa_id")));

            }
        } finally {

            // Fecha a conexão com o banco de dados, o PreparedStatement e o ResultSet
            if (rs != null) {
                rs.close();
            }

            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        return retorno;
    }

    // Método para inserir um telefone na tabela
    public void insert(TelefoneModels telefone) throws SQLException {

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {

            conn = new DataBase().getConnection();
            pstmt = conn.prepareStatement(INSERT);

            pstmt.setInt(1, telefone.getId());
            pstmt.setString(2, telefone.getNumero());
            pstmt.setInt(3, mapearTipoConta(telefone.getOperadora()));
            pstmt.setString(4, telefone.getRa());
            pstmt.setInt(5, telefone.getAgencia().getId());
            pstmt.setInt(6, telefone.getPessoa().getId());

            pstmt.executeUpdate();
        } finally {

            // Fecha a conexão com o banco de dados e o PreparedStatement
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
    }

    // Método para deletar um telefone na tabela pelo ID
    public void deleteById(int id) throws SQLException {

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {

            conn = new DataBase().getConnection();
            pstmt = conn.prepareStatement(DELETE_BY_ID);

            pstmt.setInt(1, id);

            pstmt.executeUpdate();
        } finally {

            // Fecha a conexão com o banco de dados e o PreparedStatement
            if (pstmt != null) {
                pstmt.close();
            }

            if (conn != null) {
                conn.close();
            }
        }
    }

    // Método para atualizar um telefone na tabela pelo ID
    public void update(TelefoneModels telefone) throws SQLException {

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {

            conn = new DataBase().getConnection();
            pstmt = conn.prepareStatement(UPDATE);

            pstmt.setString(1, telefone.getNumero());
            pstmt.setInt(2, mapearTipoConta(telefone.getOperadora()));
            pstmt.setString(3, telefone.getRa());
            pstmt.setInt(4, telefone.getAgencia().getId());
            pstmt.setInt(5, telefone.getPessoa().getId());
            pstmt.setInt(6, telefone.getId());

            pstmt.executeUpdate();
        } finally {

            // Fecha a conexão com o banco de dados e o PreparedStatement
            if (pstmt != null) {
                pstmt.close();
            }

            if (conn != null) {
                conn.close();
            }
        }
    }

// Método para mapear o TipoOperadoraEnum para o TipoContaEnum
    private int mapearTipoConta(TipoOperadoraEnum tipoOp) {
        if (tipoOp == TipoOperadoraEnum.TIM) {
            return 1;
        } else if (tipoOp == TipoOperadoraEnum.CLARO) {
            return 2;
        } else if (tipoOp == TipoOperadoraEnum.VIVO) {
            return 3;
        } else if (tipoOp == TipoOperadoraEnum.OI) {
            return 4;
        } else if (tipoOp == TipoOperadoraEnum.CORREIOS) {
            return 5; 
        } else {
            throw new IllegalArgumentException(" Tipo de operadora inválida!! " + tipoOp);
        }
    }

    public void delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
