package br.unipar.central.DAO;

import br.unipar.central.enums.TipoTransacaoEnum;
import br.unipar.central.models.TransacaoModels;
import br.unipar.central.util.DataBase;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TransacaoDAO {

    // Declaração de constantes para as queries SQL
    private static final String INSERT = "INSERT INTO transacao(id, valor, datahora, tipo, ra, conta_origem, conta_destino) VALUES(?, ?, ?, ?::INTEGER, ?, ?, ?)";

    private static final String FIND_ALL = "SELECT id, datahora, valor, tipo, ra, conta_origem, conta_destino FROM transacao ";

    private static final String FIND_BY_ID = "SELECT id, datahora, valor, tipo, ra, conta_origem, conta_destino FROM transacao WHERE id = ? ";

    private static final String DELETE_BY_ID = "DELETE FROM transacao WHERE id = ?";

    private static final String UPDATE = "UPDATE transacao SET valor = ?, datahora = ?, tipo = ?, ra = ?, conta_origem = ?, conta_destino = ? WHERE id = ?";

    // Método que busca todas as transações no banco de dados e retorna uma lista de objetos TransacaoModels
    public List<TransacaoModels> findAll() throws SQLException {
        ArrayList<TransacaoModels> retorno = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            // Cria uma conexão com o banco de dados
            conn = new DataBase().getConnection();

            // Prepara a query SQL
            pstmt = conn.prepareStatement(FIND_ALL);

            // Executa a query SQL
            rs = pstmt.executeQuery();

            // Itera sobre o ResultSet para popular a lista de retorno
            while (rs.next()) {
                TransacaoModels transacao = new TransacaoModels();
                transacao.setId(rs.getInt("id"));
                transacao.setValor(Double.parseDouble(rs.getString("valor")));
                transacao.setDatahora(rs.getTimestamp("datahora"));
                transacao.setTipo(TipoTransacaoEnum.paraEnum(rs.getInt("tipo")));
                transacao.setRa(rs.getString("ra"));
                transacao.setConta_origem(rs.getInt("conta_origem"));
                transacao.setConta_destino(rs.getInt("conta_destino"));

                retorno.add(transacao);
            }
        } finally {
            // Fecha conexão, PreparedStatement e ResultSet, mesmo em caso de exceção
            if (conn != null) {
                conn.close();
            }

            if (pstmt != null) {
                pstmt.close();
            }

            if (rs != null) {
                rs.close();
            }
        }

        return retorno;
    }

    // Método que busca uma transação pelo ID no banco de dados e retorna um objeto TransacaoModels
    public TransacaoModels findById(int id) throws SQLException {

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        TransacaoModels retorno = null;

        try {
            // Cria uma conexão com o banco de dados
            conn = new DataBase().getConnection();

            // Prepara a query SQL
            pstmt = conn.prepareStatement(FIND_BY_ID);

            // Define o valor do parâmetro ID na query SQL
            pstmt.setInt(1, id);

            // Executa a query SQL
            rs = pstmt.executeQuery();

            // Popula o objeto TransacaoModels com o resultado da query SQL
            while (rs.next()) {
                retorno = new TransacaoModels();
                retorno.setId(rs.getInt("id"));
                retorno.setValor(Double.parseDouble(rs.getString("valor")));
                retorno.setDatahora(rs.getTimestamp("datahora"));
                retorno.setTipo(TipoTransacaoEnum.paraEnum(rs.getInt("tipo")));
                retorno.setRa(rs.getString("ra"));
                retorno.setConta_origem(rs.getInt("conta_origem"));
                retorno.setConta_destino(rs.getInt("conta_destino"));

            }
        } finally {
            // Fecha conexão, PreparedStatement e ResultSet, mesmo em caso de exceção
            if (conn != null) {
                conn.close();
            }

            if (pstmt != null) {
                pstmt.close();
            }

            if (rs != null) {
                rs.close();
            }
        }
        return retorno;
    }

    // Método que insere uma nova transação no banco de dados
    public void insert(TransacaoModels transacao) throws SQLException {

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // Cria uma conexão com o banco de dados
            conn = new DataBase().getConnection();

            // Prepara a query SQL
            pstmt = conn.prepareStatement(INSERT);

            // Define os valores dos parâmetros na query SQL
            pstmt.setInt(1, transacao.getId());
            pstmt.setDouble(2, transacao.getValor());
            pstmt.setTimestamp(3, transacao.getDatahora());
            pstmt.setInt(4, mapearTipoConta(transacao.getTipo()));
            pstmt.setString(5, transacao.getRa());
            pstmt.setInt(6, transacao.getConta_origem());
            pstmt.setInt(7, transacao.getConta_destino());

            // Executa a query SQL
            pstmt.executeUpdate();
        } finally {
            // Fecha conexão e PreparedStatement, mesmo em caso de exceção
            if (pstmt != null) {
                pstmt.close();
            }

            if (conn != null) {
                conn.close();
            }
        }

    }

    // Método que atualiza uma transação no banco de dados
    public void update(TransacaoModels transacao) throws SQLException {

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // Cria uma conexão com o banco de dados
            conn = new DataBase().getConnection();

            // Prepara a query SQL
            pstmt = conn.prepareStatement(UPDATE);

            // Define os valores dos parâmetros na query SQL
            pstmt.setDouble(1, transacao.getValor());
            pstmt.setTimestamp(2, transacao.getDatahora());
            pstmt.setInt(3, mapearTipoConta(transacao.getTipo()));
            pstmt.setString(4, transacao.getRa());
            pstmt.setInt(5, transacao.getConta_origem());
            pstmt.setInt(6, transacao.getConta_destino());
            pstmt.setInt(7, transacao.getId());

            // Executa a query SQL
            pstmt.executeUpdate();

        } finally {
            // Fecha conexão e PreparedStatement, mesmo em caso de exceção
            if (pstmt != null) {
                pstmt.close();
            }

            if (conn != null) {
                conn.close();
            }
        }

    }

    // Método que deleta uma transação no banco de dados pelo ID
    public void delete(int id) throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // Cria uma conexão com o banco de dados
            conn = new DataBase().getConnection();

            // Prepara a query SQL
            pstmt = conn.prepareStatement(DELETE_BY_ID);

            // Define o valor do parâmetro ID na query SQL
            pstmt.setInt(1, id);

            // Executa a query SQL
            pstmt.executeUpdate();

        } finally {
            // Fecha conexão e PreparedStatement, mesmo em caso de exceção
            if (pstmt != null) {
                pstmt.close();
            }

            if (conn != null) {
                conn.close();
            }
        }
    }

    // Método auxiliar que mapeia um TipoTransacaoEnum para um valor inteiro que representa o tipo no banco de dados
    private int mapearTipoConta(TipoTransacaoEnum tipoOp) {
        if (tipoOp == TipoTransacaoEnum.CREDITO) {
            return 1;
        } else if (tipoOp == TipoTransacaoEnum.DEBITO) {
            return 2;
        } else if (tipoOp == TipoTransacaoEnum.OUTROS) {
            return 0;
        } else if (tipoOp == TipoTransacaoEnum.PIX) {
            return 3;
        } else {
            throw new IllegalArgumentException("Escolha outra operadora: " + tipoOp);
        }
    }
}