    package br.unipar.central;

    import br.unipar.central.executions.*;
    import java.util.Scanner;

    public class UniparCentral {

    private static Scanner scanner;

    public static void main(String[] args) {

    AgenciaExecution agenciaExecution = new AgenciaExecution();
    BancoExecution bancoExecution = new BancoExecution();
    CidadeExecution cidadeExecution = new CidadeExecution();
    ContaExecution contaExecution = new ContaExecution();
    EnderecoExecution enderecoExecution = new EnderecoExecution();
    EstadoExecution estadoExecution = new EstadoExecution();
    PaisExecution paisExecution = new PaisExecution();
    PessoaExecution pessoaExecution = new PessoaExecution();
    PessoaFisicaExecution pessoaFisicaExecution = new PessoaFisicaExecution();
    PessoaJuridicaExecution pessoaJuridicaExecution = new PessoaJuridicaExecution();
    TelefoneExecution telefoneExecution = new TelefoneExecution();
    TransacaoExecution transacaoExecution = new TransacaoExecution();
    //instâncias de várias classes de execução.Para poder executar diferentes Entidades tais como a propria  agencia
    //banco,telefone,cidade etc
    boolean sair = false;
    boolean sair2 = false;

    scanner = new Scanner(System.in);
    //Scanner, que será usado para ler entradas do usuário.

    while (!sair) {
    //Criação do Menu principal que o Usuareo utilizará para mexer nele
    //Assim exibindo esse menu e mostrando as opção que o usuareo possa mexer    
/*
<><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
<>                                                      <>
<>            PPPP   OOOO   OOOO                        <>
<>            P   P  O   O  O   O                       <>
<>            PPPP   O   O  O   O                       <>
<>            P      O   O  O   O                       <>
<>            P      OOOO   OOOO                        <>
<>                                                      <>
<>                                                      <>   
<>            BBBBB   AAAAA   N   N   CCCCC   OOOOO     <>         
<>            B    B  A    A  NN  N  C       O    O     <>         
<>            BBBBB   AAAAAA  N N N  C       O    O     <>         
<>            B    B  A    A  N  NN  C       O    O     <>         
<>            BBBBB   A    A  N   N   CCCCC   OOOOO     <>  
<>                                                      <>
<><><><><><><><><><><><><><><><><><><><><><><><><><><><><>   
*/
    

    System.out.println("<><><> MENU <><><>");
    
    System.out.println("<< 1 >> AGÊNCIA");

    System.out.println("<< 2 >> BANCO");

    System.out.println("<< 3 >> CIDADE");

    System.out.println("<< 4 >> CONTA");

    System.out.println("<< 5 >> ENDERECO");

    System.out.println("<< 6 >> ESTADO");

    System.out.println("<< 7 >> PAIS");

    System.out.println("<< 8 >> PESSOA");

    System.out.println("<< 9 >> PESSOA FÍSICA");

    System.out.println("<< 10 >> PESSOA JURÍDICA");

    System.out.println("<< 11 >> TELEFONE");

    System.out.println("<< 12 >> TRANSAÇÃO");

    System.out.println("<< 13 >> SAIR");

    System.out.println("<><><> MENU <><><>");
    //Nessa parte do codigo o programa irá ler e a opção que foi escolhida pelo USUARIO
    //Ultilizando á Switch para verficação de linhas e assim que indentificadas utiliza o
    //Break para sair do loop;

    int opcao = scanner.nextInt();
    sair2 = false;
    switch (opcao) {

    case 1:
    while (!sair2) {
    System.out.println("<><><> AGÊNCIA <><><>");

    System.out.println("<< 1 >> INSERIR NOVA AGÊNCIA");

    System.out.println("<< 2 >> VER TODAS AS AGÊNCIAS CADASTRADAS");

    System.out.println("<< 3 >> VER A AGÊNCIA PELO ID");

    System.out.println("<< 4 >> DELETAR UMA AGÊNCIA PELO ID");

    System.out.println("<< 5 >> ATUALIZAR DADOS DA AGÊNCIA PELO ID");

    System.out.println("<< 6 >> RETORNAR");

    System.out.println("<><><> AGÊNCIA <><><>");

    int opcao2 = scanner.nextInt();

    switch (opcao2) {
    case 1:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");

        transacaoExecution.Insert();
        break;
    case 2:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");

        transacaoExecution.FindAll();
        break;
    case 3:
        System.out.println("<><><><><----- <> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");

        transacaoExecution.FindById();
        break;
    case 4:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");

        transacaoExecution.DeleteById();
        break;
    case 5:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");

        transacaoExecution.Update();
        break;
    case 6:
        sair2 = true;
        break;
    default:
        System.out.println("Opção não Foi Encontrada !!!! POR FAVOR TENTE DE OUTRO MODO");
            }
        }
    break;
    case 2:
    while (!sair2) {
    System.out.println("<><><> BANCO <><><>");

    System.out.println("<< 1 >> INSERIR NOVO BANCO");

    System.out.println("<< 2 >> VER TODAS OS BANCOS CADASTRADOS");

    System.out.println("<< 3 >> VER O BANCO PELO ID");

    System.out.println("<< 4 >> DELETAR UM BANCO PELO ID");

    System.out.println("<< 5 >> ATUALIZAR DADOS DO BANCO PELO ID");

    System.out.println("<< 6 >> RETORNAR");

    System.out.println("<><><> BANCO <><><>");


    int opcao2 = scanner.nextInt();

    switch (opcao2) {
    case 1:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.Insert();
        break;
    case 2:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.FindAll();
        break;
    case 3:
        System.out.println("<><><><><----- <> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.FindById();
        break;
    case 4:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.DeleteById();
        break;
    case 5:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.Update();
        break;
    case 6:
        sair2 = true;
        break;
    default:
        System.out.println("Opção não Foi Encontrada !!!! POR FAVOR TENTE DE OUTRO MODO");
            }
        }
    break;
    case 3:
    while (!sair2) {
    System.out.println("<><><> CIDADE <><><>");

    System.out.println("<< 1 >> INSERIR NOVA CIDADE");

    System.out.println("<< 2 >> VER TODAS AS CIDADES CADASTRADAS (CUIDADOOOOO... ISSO PODE DEMORAR MUITOOOOOOO, MAS MUITOOOOO MESMOOOOO!!");

    System.out.println("<< 3 >> VER A CIDADE PELO ID");

    System.out.println("<< 4 >> DELETAR UMA CIDADE PELO ID");

    System.out.println("<< 5 >> ATUALIZAR DADOS DE UMA CIDADE PELO ID");

    System.out.println("<< 6 >> RETORNAR");

    System.out.println("<><><> CIDADE <><><>");

    int opcao2 = scanner.nextInt();

    switch (opcao2) {
    case 1:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.Insert();
        break;
    case 2:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.FindAll();
        break;
    case 3:
        System.out.println("<><><><><----- <> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.FindById();
        break;
    case 4:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.DeleteById();
        break;
    case 5:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.Update();
        break;
    case 6:
        sair2 = true;
        break;
    default:
        System.out.println("Opção não Foi Encontrada !!!! POR FAVOR TENTE DE OUTRO MODO");
            }
        }
    break;
    case 4:
    while (!sair2) {
    System.out.println("<><><> CONTA <><><>");

    System.out.println("<< 1 >> INSERIR NOVA CONTA");

    System.out.println("<< 2 >> VER TODAS AS CONTAS CADASTRADAS");

    System.out.println("<< 3 >> VER A CONTA PELO ID");

    System.out.println("<< 4 >> DELETAR UMA CONTA PELO ID");

    System.out.println("<< 5 >> ATUALIZAR DADOS DE UMA CONTA PELO ID");

    System.out.println("<< 6 >> RETORNAR");

    System.out.println("<><><> CONTA <><><>");


    int opcao2 = scanner.nextInt();

    switch (opcao2) {
    case 1:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.Insert();
        break;
    case 2:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.FindAll();
        break;
    case 3:
        System.out.println("<><><><><----- <> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.FindById();
        break;
    case 4:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.DeleteById();
        break;
    case 5:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.Update();
        break;
    case 6:
        sair2 = true;
        break;
    default:
        System.out.println("Opção não Foi Encontrada !!!! POR FAVOR TENTE DE OUTRO MODO");
            }
        }
    break;
    case 5:
    while (!sair2) {
    System.out.println("<><><> ENDEREÇO <><><>");

    System.out.println("<< 1 >> INSERIR NOVO ENDEREÇO");

    System.out.println("<< 2 >> VER TODAS OS ENDEREÇOS CADASTRADOS");

    System.out.println("<< 3 >> VER O ENDEREÇO PELO ID");

    System.out.println("<< 4 >> DELETAR UM ENDEREÇO PELO ID");

    System.out.println("<< 5 >> ATUALIZAR DADOS DE UM ENDEREÇO PELO ID");

    System.out.println("<< 6 >> RETORNAR");

    System.out.println("<><><> ENDEREÇO <><><>");


    int opcao2 = scanner.nextInt();

    switch (opcao2) {
    case 1:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.Insert();
        break;
    case 2:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.FindAll();
        break;
    case 3:
        System.out.println("<><><><><----- <> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.FindById();
        break;
    case 4:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.DeleteById();
        break;
    case 5:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.Update();
        break;
    case 6:
        sair2 = true;
        break;
    default:
        System.out.println("Opção não Foi Encontrada !!!! POR FAVOR TENTE DE OUTRO MODO");
            }
        }
    break;
    case 6:
    while (!sair2) {
    System.out.println("<><><> ESTADO <><><>");

    System.out.println("<< 1 >> INSERIR NOVO ESTADO");

    System.out.println("<< 2 >> VER TODAS OS ESTADOS CADASTRADOS");

    System.out.println("<< 3 >> VER O ESTADO PELO ID");

    System.out.println("<< 4 >> DELETAR UM ESTADO PELO ID");

    System.out.println("<< 5 >> ATUALIZAR DADOS DE UM ESTADO PELO ID");

    System.out.println("<< 6 >> RETORNAR");

    System.out.println("<><><> ESTADO <><><>");

    int opcao2 = scanner.nextInt();

    switch (opcao2) {
    case 1:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.Insert();
        break;
    case 2:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.FindAll();
        break;
    case 3:
        System.out.println("<><><><><----- <> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.FindById();
        break;
    case 4:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.DeleteById();
        break;
    case 5:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.Update();
        break;
    case 6:
        sair2 = true;
        break;
    default:
        System.out.println("Opção não Foi Encontrada !!!! POR FAVOR TENTE DE OUTRO MODO");
            }
        }
    break;
    case 7:
    while (!sair2) {
    System.out.println("<><><> PAIS <><><>");

    System.out.println("<< 1 >> INSERIR NOVO PAÍS");

    System.out.println("<< 2 >> VER TODAS OS PAÍSES CADASTRADOS");

    System.out.println("<< 3 >> VER O PAÍS PELO ID");

    System.out.println("<< 4 >> DELETAR UM PAÍS PELO ID");

    System.out.println("<< 5 >> ATUALIZAR DADOS DE UM PAÍS PELO ID");

    System.out.println("<< 6 >> RETORNAR");

    System.out.println("<><><> PAIS <><><>");

    int opcao2 = scanner.nextInt();

    switch (opcao2) {
    case 1:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.Insert();
        break;
    case 2:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.FindAll();
        break;
    case 3:
        System.out.println("<><><><><----- <> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.FindById();
        break;
    case 4:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.DeleteById();
        break;
    case 5:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.Update();
        break;
    case 6:
        sair2 = true;
        break;
    default:
        System.out.println("Opção não Foi Encontrada !!!! POR FAVOR TENTE DE OUTRO MODO");
            }
        }
    break;
    case 8:
    while (!sair2) {
    System.out.println("<><><> PESSOA <><><>");

    System.out.println("<< 1 >> INSERIR NOVA PESSOA");

    System.out.println("<< 2 >> VER TODAS AS PESSOAS CADASTRADAS");

    System.out.println("<< 3 >> VER A PESSOA PELO ID");

    System.out.println("<< 4 >> DELETAR UMA PESSOA PELO ID");

    System.out.println("<< 5 >> ATUALIZAR DADOS DE UMA PESSOA PELO ID");

    System.out.println("<< 6 >> RETORNAR");

    System.out.println("<><><> PESSOA <><><>");

    int opcao2 = scanner.nextInt();

    switch (opcao2) {
    case 1:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.Insert();
        break;
    case 2:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.FindAll();
        break;
    case 3:
        System.out.println("<><><><><----- <> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.FindById();
        break;
    case 4:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.DeleteById();
        break;
    case 5:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.Update();
        break;
    case 6:
        sair2 = true;
        break;
    default:
        System.out.println("Opção não Foi Encontrada !!!! POR FAVOR TENTE DE OUTRO MODO");
            }
        }
    break;
    case 9:
    while (!sair2) {
    System.out.println("<><><> PESSOA FÍSICA <><><>");

    System.out.println("<< 1 >> INSERIR NOVA PESSOA FÍSICA");

    System.out.println("<< 2 >> VER TODAS AS PESSOAS FÍSICAS CADASTRADAS");

    System.out.println("<< 3 >> VER A PESSOA FÍSICA PELO CPF");

    System.out.println("<< 4 >> DELETAR UMA PESSOA FÍSICA PELO CPF");

    System.out.println("<< 5 >> ATUALIZAR DADOS DE UMA PESSOA FÍSICA PELO CPF");

    System.out.println("<< 6 >> RETORNAR");

    System.out.println("<><><> PESSOA FÍSICA <><><>");

    int opcao2 = scanner.nextInt();

    switch (opcao2) {
    case 1:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.Insert();
        break;
    case 2:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.FindAll();
        break;
    case 3:
        System.out.println("<><><><><----- <> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.FindById();
        break;
    case 4:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.DeleteById();
        break;
    case 5:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.Update();
        break;
    case 6:
        sair2 = true;
        break;
    default:
        System.out.println("Opção não Foi Encontrada !!!! POR FAVOR TENTE DE OUTRO MODO");
            }
        }
    break;
    case 10:
    while (!sair2) {
    System.out.println("<><><> PESSOA JURÍDICA <><><>");

    System.out.println("<< 1 >> INSERIR NOVA PESSOA JURÍDICA");

    System.out.println("<< 2 >> VER TODAS AS PESSOAS JURÍDICA CADASTRADAS");

    System.out.println("<< 3 >> VER A PESSOA JURÍDICA PELO CNPJ");

    System.out.println("<< 4 >> DELETAR UMA PESSOA JURÍDICA PELO CNPJ");

    System.out.println("<< 5 >> ATUALIZAR DADOS DE UMA PESSOA JURÍDICA PELO CNPJ");

    System.out.println("<< 6 >> RETORNAR");

    System.out.println("<><><> PESSOA JURÍDICA <><><>");


    int opcao2 = scanner.nextInt();

    switch (opcao2) {
    case 1:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.Insert();
        break;
    case 2:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.FindAll();
        break;
    case 3:
        System.out.println("<><><><><----- <> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.FindById();
        break;
    case 4:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.DeleteById();
        break;
    case 5:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.Update();
        break;
    case 6:
        sair2 = true;
        break;
    default:
        System.out.println("Opção não Foi Encontrada !!!! POR FAVOR TENTE DE OUTRO MODO");
            }
        }
    break;
    case 11:
    while (!sair2) {
    System.out.println("<><><> TELEFONE <><><>");

    System.out.println("<< 1 >> INSERIR NOVO TELEFONE");

    System.out.println("<< 2 >> VER TODAS OS TELEFONES CADASTRADAS");

    System.out.println("<< 3 >> VER A TELEFONE PELO ID");

    System.out.println("<< 4 >> DELETAR UM TELEFONE PELO ID");

    System.out.println("<< 5 >> ATUALIZAR DADOS DE UM TELEFONE PELO ID");

    System.out.println("<< 6 >> RETORNAR");

    System.out.println("<><><> TELEFONE <><><>");


    int opcao2 = scanner.nextInt();

    switch (opcao2) {
    case 1:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.Insert();
        break;
    case 2:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.FindAll();
        break;
    case 3:
        System.out.println("<><><><><----- <> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.FindById();
        break;
    case 4:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.DeleteById();
        break;
    case 5:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.Update();
        break;
    case 6:
        sair2 = true;
        break;
    default:
        System.out.println("Opção não Foi Encontrada !!!! POR FAVOR TENTE DE OUTRO MODO");
            }
        }
    break;
    case 12:
    while (!sair2) {
    System.out.println("<><><>TRANSAÇÃO<><><>");

    System.out.println("<< 1 >> INSERIR NOVA TRANSAÇÃO");

    System.out.println("<< 2 >> VER TODAS AS TRANSAÇÕES CADASTRADAS");

    System.out.println("<< 3 >> VER A TRANSAÇÃO PELO ID");

    System.out.println("<< 4 >> DELETAR UM TRANSAÇÃO PELO ID");

    System.out.println("<< 5 >> ATUALIZAR DADOS DE UMA TRANSAÇÃO PELO ID");

    System.out.println("<< 6 >> RETORNAR");

    System.out.println("<><><>TRANSAÇÃO<><><>");


    int opcao2 = scanner.nextInt();

    switch (opcao2) {
    case 1:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.Insert();
        break;
    case 2:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.FindAll();
        break;
    case 3:
        System.out.println("<><><><><----- <> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.FindById();
        break;
    case 4:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.DeleteById();
        break;
    case 5:
        System.out.println("<><><><><-----<> Essa operação pode levar mais tempo do que o usual. <>-----><><><><>");
        transacaoExecution.Update();
        break;
    case 6:
        sair2 = true;
        break;
    default:
        System.out.println("Opção não Foi Encontrada !!!! POR FAVOR TENTE DE OUTRO MODO");
            }
        }
    break;
    case 13:
    sair = true;
    break;

    default:
    System.out.println("Opção não Foi Encontrada !!!! POR FAVOR TENTE DE OUTRO MODO");
            }
        }

    }
}
