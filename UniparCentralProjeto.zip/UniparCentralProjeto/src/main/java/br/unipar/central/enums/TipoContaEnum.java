package br.unipar.central.enums;

public enum TipoContaEnum {

    // Declaração dos tipos de conta com seus respectivos números
    CORRENTE(1),
    POUPANCA(2),
    SALARIO(3);

    // Atributo para armazenar o número do tipo de conta
    private final int numero;

    // Construtor privado que recebe o número do tipo de conta
    private TipoContaEnum(int numero) {
        this.numero = numero;
    }

    // Método getter para obter o número do tipo de conta
    public int getNumero() {
        return numero;
    }

    // Método estático que retorna um TipoContaEnum a partir de um número
    public static TipoContaEnum paraEnum(int codigo) {
        for (TipoContaEnum tipo : TipoContaEnum.values()) {
            if (tipo.getNumero() == codigo) {
                return tipo;
            }
        }
        // Se o número não corresponder a nenhum TipoContaEnum, lança uma exceção
        throw new IllegalArgumentException("Código inválido!");
    } 
}