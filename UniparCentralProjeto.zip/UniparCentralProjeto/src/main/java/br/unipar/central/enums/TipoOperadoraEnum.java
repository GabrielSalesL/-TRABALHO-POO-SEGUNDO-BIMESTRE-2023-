package br.unipar.central.enums;

public enum TipoOperadoraEnum {

    // Declaração dos tipos de operadora com seus respectivos números
    TIM(1),
    CLARO(2),
    VIVO(3),
    OI(4),
    CORREIOS(5);

    // Atributo para armazenar o número da operadora
    private final int numero;

    // Construtor privado que recebe o número da operadora
    private TipoOperadoraEnum(int numero) {
        this.numero = numero;
    }

    // Método getter para obter o número da operadora
    public int getNumero() {
        return numero;
    }

    // Método estático que retorna um TipoOperadoraEnum a partir de um número
    public static TipoOperadoraEnum paraEnum(int codigo) {
        for (TipoOperadoraEnum tipo : TipoOperadoraEnum.values()) {
            if (tipo.getNumero() == codigo) {
                return tipo;
            }
        }
        // Se o número não corresponder a nenhum TipoOperadoraEnum, lança uma exceção
        throw new IllegalArgumentException("Código inválido!");
    } 
}