package br.unipar.central.enums;

public enum TipoTransacaoEnum {

// Definição dos valores possíveis para o enum (DEBITO, CREDITO, PIX e OUTROS)
DEBITO(1),
CREDITO(2),
PIX(3),
OUTROS(0);

// Atributo que armazena o número correspondente ao valor do enum
private final int numero;

// Construtor que recebe um número e atribui ao atributo "numero" do enum correspondente
private TipoTransacaoEnum(int numero) {
    this.numero = numero;
}

// Método que retorna o número correspondente ao valor do enum
public int getNumero() {
    return numero;
}

// Método que recebe um número e retorna o enum correspondente a esse número
public static TipoTransacaoEnum paraEnum(int codigo) {
    // Percorre todos os valores do enum
    for (TipoTransacaoEnum tipo : TipoTransacaoEnum.values()) {
        // Verifica se o número do enum é igual ao número informado
        if (tipo.getNumero() == codigo) {
            // Retorna o enum correspondente caso encontre
            return tipo;
        }
    }
    // Caso não encontre, lança uma exceção informando que o código é inválido
    throw new IllegalArgumentException("Código inválido!");
} 
}