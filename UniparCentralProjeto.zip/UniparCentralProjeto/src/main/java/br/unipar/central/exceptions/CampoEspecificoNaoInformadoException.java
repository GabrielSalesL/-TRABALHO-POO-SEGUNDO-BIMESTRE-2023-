package br.unipar.central.exceptions;

public class CampoEspecificoNaoInformadoException extends Exception {

    public CampoEspecificoNaoInformadoException(String campo) {
        super("Por favor, preencha o campo " + campo + " antes de continuar");
    }

}
