package br.unipar.central.exceptions;

public class EntidadeOuClasseEmBrancoOuNaoInformadaException extends Exception {

    public EntidadeOuClasseEmBrancoOuNaoInformadaException(String entidade) {
        super("O campo '" + entidade + "' é obrigatório e deve ser preenchido. "
                + "Por favor, verifique suas informações e tente novamente.");
    }

}
