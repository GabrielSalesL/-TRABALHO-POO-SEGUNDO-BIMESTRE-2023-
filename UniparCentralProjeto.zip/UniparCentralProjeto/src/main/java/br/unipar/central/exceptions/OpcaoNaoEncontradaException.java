package br.unipar.central.exceptions;

public class OpcaoNaoEncontradaException extends Exception {

    public OpcaoNaoEncontradaException() {
        super("Por favor verifique a opção, não foi encontrada!!");
    }
}
