
package br.unipar.central.exceptions;

public class SaldoZeradoException extends Exception{

    public SaldoZeradoException(String campo) {
        super("O campo "+campo+" deve ser inicializado com o valor 0 para continuar.");
    }
    
}
