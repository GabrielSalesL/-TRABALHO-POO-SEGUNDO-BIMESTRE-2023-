package br.unipar.central.executions;

import br.unipar.central.models.AgenciaModels;
import br.unipar.central.models.BancoModels;
import br.unipar.central.services.AgenciaService;
import java.util.List;
import java.util.Scanner;

public class AgenciaExecution {

    public String Insert() {
        try {
            AgenciaModels agencia = new AgenciaModels();
            Scanner scanner = new Scanner(System.in);

            // Solicita o ID da agência
            System.out.println("Digite o ID da agência: ");
            agencia.setId(scanner.nextInt());
            scanner.nextLine();

            // Solicita o código da agência
            System.out.println("Digite o código da agência: ");
            agencia.setCodigo(scanner.nextLine());

            // Solicita o dígito da agência
            System.out.println("Digite o dígito da agência: ");
            agencia.setDigito(scanner.nextLine());

            // Solicita a razão social da agência
            System.out.println("Digite a razão social da agência: ");
            agencia.setRazaoSocial(scanner.nextLine());

            // Solicita o CNPJ da agência
            System.out.println("Digite o CNPJ da agência: ");
            agencia.setCnpj(scanner.nextLine());

            // Solicita o RA do aluno que está cadastrando a agência
            System.out.println("Digite o RA do aluno que está cadastrando essa agência: ");
            agencia.setRa(scanner.nextLine());

            // Solicita o ID do banco atrelado a essa agência
            System.out.println("Digite o ID do banco atrelado a essa agência: ");
            BancoModels bancoPOJO = new BancoModels();
            bancoPOJO.setId(scanner.nextInt());
            agencia.setBanco(bancoPOJO);

            AgenciaService agenciaService = new AgenciaService();
            agenciaService.insert(agencia);

            String msg = "Agência inserida com sucesso";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    public String FindAll() {
        try {
            AgenciaService agenciaService = new AgenciaService();
            List<AgenciaModels> agencias = agenciaService.findAll();

            String msg = "Todas as agências encontradas: " + agencias.toString();
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    public String FindById() {
        try {
            AgenciaService agenciaService = new AgenciaService();
            AgenciaModels agencia = new AgenciaModels();
            Scanner scanner = new Scanner(System.in);

            // Solicita o ID da agência a ser buscada
            System.out.println("Digite o ID da agência para realizar a busca: ");
            int id = scanner.nextInt();
            agencia.setId(id);

            String msg = "Agência encontrada: " + agenciaService.findById(agencia.getId()).toString();
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    public String DeleteById() {
        try {
            Scanner scanner = new Scanner(System.in);
            AgenciaService agenciaService = new AgenciaService();
            AgenciaModels agencia = new AgenciaModels();

            // Solicita o ID da agência a ser deletada
            System.out.println("Digite o ID da agência que deseja deletar: ");
            agencia.setId(scanner.nextInt());

            agenciaService.delete(agencia.getId());

            String msg = "Agência deletada com sucesso";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    public String Update() {
        try {
            AgenciaModels agencia = new AgenciaModels();
            Scanner scanner = new Scanner(System.in);

            // Solicita o ID da agência a ser atualizada
            System.out.println("Digite o ID da agência que deseja atualizar: ");
            agencia.setId(scanner.nextInt());
            scanner.nextLine();

            // Solicita o novo código da agência
            System.out.println("Digite o novo código da agência: ");
            agencia.setCodigo(scanner.nextLine());

            // Solicita o novo dígito da agência
            System.out.println("Digite o novo dígito da agência: ");
            agencia.setDigito(scanner.nextLine());

            // Solicita a nova razão social da agência
            System.out.println("Digite a nova razão social da agência: ");
            agencia.setRazaoSocial(scanner.nextLine());

// Solicita o novo CNPJ da agência
            System.out.println("Digite o novo CNPJ da agência: ");
            agencia.setCnpj(scanner.nextLine());

            // Solicita o RA do aluno que está realizando a atualização
            System.out.println("Digite o RA do aluno que está realizando a atualização: ");
            agencia.setRa(scanner.nextLine());

            // Solicita o ID do banco atrelado a essa agência
            System.out.println("Digite o ID do banco atrelado a essa agência: ");
            BancoModels bancoPOJO = new BancoModels();
            bancoPOJO.setId(scanner.nextInt());
            agencia.setBanco(bancoPOJO);

            AgenciaService agenciaService = new AgenciaService();
            agenciaService.update(agencia);

            String msg = "Agência atualizada com sucesso";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }
}
