package br.unipar.central.executions;

import br.unipar.central.models.BancoModels;
import br.unipar.central.services.BancoService;
import java.util.List;
import java.util.Scanner;

public class BancoExecution {

    // Método para inserir um novo banco
    public String Insert() {
        try {
            BancoModels banco = new BancoModels();
            Scanner scanner = new Scanner(System.in);

            // Solicita o ID do banco
            System.out.println("Digite o ID do banco: ");
            banco.setId(scanner.nextInt());
            scanner.nextLine();

            // Solicita o nome do banco
            System.out.println("Digite o nome do banco: ");
            banco.setNome(scanner.nextLine());

            // Solicita o RA do aluno que está cadastrando o banco
            System.out.println("Digite o RA do aluno que está cadastrando esse banco: ");
            banco.setRa(scanner.nextLine());

            BancoService bancoService = new BancoService();
            bancoService.insert(banco);

            String msg = "Banco inserido com sucesso";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    // Método para buscar todos os bancos cadastrados
    public String FindAll() {
        try {
            BancoService bancoService = new BancoService();
            List<BancoModels> bancos = bancoService.findAll();

            // Imprime uma mensagem de cabeçalho
            BancoModels bancoPOJO = new BancoModels();
            bancoPOJO.message();

            String msg = "Todos os bancos encontrados: " + bancos.toString();
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    // Método para buscar um banco pelo seu ID
    public String FindById() {
        try {
            BancoService bancoService = new BancoService();
            BancoModels banco = new BancoModels();
            Scanner scanner = new Scanner(System.in);

            // Solicita o ID do banco a ser buscado
            System.out.println("Digite o ID do banco para realizar a busca: ");
            int id = scanner.nextInt();
            banco.setId(id);

            // Imprime uma mensagem de cabeçalho
            BancoModels bancoPOJO = new BancoModels();
            bancoPOJO.message();

            String msg = "Banco encontrado: " + bancoService.findById(banco.getId());
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    // Método para deletar um banco pelo seu ID
    public String DeleteById() {
        try {
            Scanner scanner = new Scanner(System.in);

            BancoService bancoService = new BancoService();
            BancoModels banco = new BancoModels();

            // Solicita o ID do banco a ser deletado
            System.out.println("Digite o ID do banco que deseja deletar: ");
            banco.setId(scanner.nextInt());

            bancoService.delete(banco.getId());

            String msg = "Banco deletado com sucesso";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    // Método para atualizar as informações de um banco
    public String Update() {
        try {
            BancoModels banco = new BancoModels();
            Scanner scanner = new Scanner(System.in);

            // Solicita o ID do banco a ser atualizado
            System.out.println("Digite o ID do banco que deseja atualizar: ");
            banco.setId(scanner.nextInt());
            scanner.nextLine();

            // Solicita o novo nome do banco
            System.out.println("Digite o novo nome do banco: ");
            banco.setNome(scanner.nextLine());

            // Solicita o RA do aluno que está realizando a atualização
            System.out.println("Digite o RA do aluno que está realizando a atualização: ");
            banco.setRa(scanner.nextLine());

            BancoService bancoService = new BancoService();
            bancoService.update(banco);

            String msg = "Banco atualizado com sucesso";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }
    
}