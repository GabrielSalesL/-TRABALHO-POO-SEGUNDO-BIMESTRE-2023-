package br.unipar.central.executions;

import br.unipar.central.models.CidadeModels;
import br.unipar.central.models.EstadoModels;
import br.unipar.central.services.CidadeService;
import java.util.List;
import java.util.Scanner;

public class CidadeExecution {
    
        // Método para inserir uma nova cidade
    public String Insert() {
        try {
            CidadeModels cidade = new CidadeModels();
            Scanner scanner = new Scanner(System.in);

            // Solicita o ID da cidade
            System.out.println("Digite o ID da cidade: ");
            cidade.setId(scanner.nextInt());
            scanner.nextLine();

            // Solicita o nome da cidade
            System.out.println("Digite o nome da cidade: ");
            cidade.setNome(scanner.nextLine());

            // Solicita o RA do aluno que está cadastrando a cidade
            System.out.println("Digite o RA do aluno que está cadastrando essa cidade: ");
            cidade.setRa(scanner.nextLine());

            // Solicita o ID do estado atrelado a esta cidade
            System.out.println("Digite o ID do estado atrelado a esta cidade: ");
            EstadoModels estadoPOJO = new EstadoModels();
            estadoPOJO.setId(scanner.nextInt());
            cidade.setEstado(estadoPOJO);

            CidadeService cidadeService = new CidadeService();
            cidadeService.insert(cidade);

            String msg = "Cidade inserida com sucesso";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }
    
 // Método para buscar todas as cidades cadastradas
    public String FindAll() {
        try {
            CidadeService cidadeService = new CidadeService();
            List<CidadeModels> cidades = cidadeService.findAll();

            // Imprime uma mensagem de cabeçalho
            CidadeModels cidadePOJO = new CidadeModels();
            cidadePOJO.message();

            String msg = "Todas as cidades encontradas: " + cidades.toString();
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    // Método para buscar uma cidade pelo seu ID
    public String FindById() {
        try {
            CidadeService cidadeService = new CidadeService();
            CidadeModels cidade = new CidadeModels();
            Scanner scanner = new Scanner(System.in);

            // Solicita o ID da cidade a ser buscada
            System.out.println("Digite o ID da cidade para realizar a busca: ");
            int id = scanner.nextInt();
            cidade.setId(id);

            // Imprime uma mensagem de cabeçalho
            CidadeModels cidadePOJO = new CidadeModels();
            cidadePOJO.message();

            String msg = "Cidade encontrada: " + cidadeService.findById(cidade.getId());
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }
    // Método para deletar uma cidade pelo seu ID
    public String DeleteById() {
        try {
            Scanner scanner = new Scanner(System.in);

            CidadeService cidadeService = new CidadeService();
            CidadeModels cidade = new CidadeModels();

            // Solicita o ID da cidade a ser deletada
            System.out.println("Digite o ID da cidade que deseja deletar: ");
            cidade.setId(scanner.nextInt());

            cidadeService.delete(cidade.getId());

            String msg = "Cidade deletada com sucesso";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }
    
// Método para atualizar as informações de uma cidade
    public String Update() {
        try {
            CidadeModels cidade = new CidadeModels();
            Scanner scanner = new Scanner(System.in);
            // Solicita o ID da cidade a ser atualizada
            System.out.println("Digite o ID da cidade que deseja atualizar: ");
            cidade.setId(scanner.nextInt());
            scanner.nextLine();

            // Solicita o novo nome da cidade
            System.out.println("Digite o novo nome da cidade: ");
            cidade.setNome(scanner.nextLine());

            // Solicita o RA do aluno que está realizando a atualização
            System.out.println("Digite o RA do aluno que está realizando a atualização: ");
            cidade.setRa(scanner.nextLine());

            // Solicita o ID do estado atrelado a esta cidade
            System.out.println("Digite o ID do estado atrelado a essa cidade: ");
            EstadoModels estadoPOJO = new EstadoModels();
            estadoPOJO.setId(scanner.nextInt());
            cidade.setEstado(estadoPOJO);
            CidadeService cidadeService = new CidadeService();
            cidadeService.update(cidade);
            String msg = "Cidade atualizada com sucesso";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }
}