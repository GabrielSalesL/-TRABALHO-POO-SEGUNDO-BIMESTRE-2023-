package br.unipar.central.executions;

import br.unipar.central.enums.TipoContaEnum;
import br.unipar.central.models.AgenciaModels;
import br.unipar.central.models.ContaModels;  
import br.unipar.central.models.PessoaModels;
import br.unipar.central.services.ContaService;
import java.util.List;
import java.util.Scanner;

public class ContaExecution {

    // Método para inserir uma nova conta
    public String insert() {
        try {
            // Cria um objeto ContaModels vazio
            ContaModels conta = new ContaModels();
            Scanner scanner = new Scanner(System.in);

            // Lê o número da conta do usuário
            System.out.println("Informe o número da conta: ");
            conta.setNumero(scanner.nextLine());

            // Lê o dígito da conta do usuário
            System.out.println("Informe o dígito da conta: ");
            conta.setDigito(scanner.nextLine());

            // Lê o saldo inicial da conta do usuário
            System.out.println("Informe o saldo inicial da conta:");
            conta.setSaldo(scanner.nextDouble());

            // Lê o tipo da conta do usuário e converte para o tipo enumerado correspondente
            System.out.println("Informe o tipo da conta (1 para corrente, 2 para poupança, 3 para salário):");
            int tipoContaInt = scanner.nextInt();
            TipoContaEnum tipoConta = null;

            switch (tipoContaInt) {
                case 1:
                    tipoConta = TipoContaEnum.CORRENTE;
                    break;
                case 2:
                    tipoConta = TipoContaEnum.POUPANCA;
                    break;
                case 3:
                    tipoConta = TipoContaEnum.SALARIO;
                    break;
                default:
                    System.out.println("Tipo de conta inválido!");
                    return "Tipo de conta inválido!";
            }
            conta.setTipoConta(tipoConta);
            scanner.nextLine();

            // Lê o RA do aluno que está inserindo a conta
            System.out.println("Informe o RA do aluno que está inserindo essa conta: ");
            conta.setRa(scanner.nextLine());

            // Lê o ID da agência atrelada à conta
            System.out.println("Informe o ID da agência atrelada a essa conta: ");
            AgenciaModels agenciaPOJO = new AgenciaModels();
            agenciaPOJO.setId(scanner.nextInt());
            conta.setAgencia(agenciaPOJO);

            // Lê o ID da pessoa atrelada à conta
            System.out.println("Informe o ID da pessoa atrelada a essa conta: ");
            PessoaModels pessoaPOJO = new PessoaModels();
            pessoaPOJO.setId(scanner.nextInt());
            conta.setPessoa(pessoaPOJO);

            // Chama o serviço para inserir a conta no banco de dados
            ContaService contaService = new ContaService();
            contaService.insert(conta);

            String msg = "Conta inserida com sucesso!";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }
    // Método para buscar todas as contas cadastradas
    public String findAll() {
        try {
            // Chama o serviço para buscar todas as contas no banco de dados
            ContaService contaService = new ContaService();
            List<ContaModels> contas = contaService.findAll();
            
            // Imprime uma mensagem de cabeçalho
            ContaModels contaPOJO = new ContaModels();
            contaPOJO.message();

            // Imprime a lista de contas encontradas
            String msg = "Todas as contas encontradas: " + contas.toString();
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    // Método para buscar uma conta pelo ID
    public String findById() {
        try {
            ContaService contaService = new ContaService();
            ContaModels conta = new ContaModels();
            Scanner scanner = new Scanner(System.in);

            System.out.println("Informe o ID da conta para realizar a busca: ");
            int id = scanner.nextInt();
            conta.setId(id);
            ContaModels contaPOJO = new ContaModels();
            contaPOJO.message();
            String msg = "Conta encontrada: " + contaService.findById(conta.getId());
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    // Método para deletar uma conta pelo ID
    public String deleteById() {
        try {
            Scanner scanner = new Scanner(System.in);

            // Cria um objeto ContaModels vazio
            ContaModels conta = new ContaModels();

            // Lê o ID da conta que o usuário quer deletar
            System.out.println("Informe o ID da conta que deseja deletar: ");
            conta.setId(scanner.nextInt());

            // Chama o serviço para deletar a conta no banco de dados
            ContaService contaService = new ContaService();
            contaService.delete(conta.getId());

            String msg = "Conta deletada com sucesso!";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    // Método para atualizar uma conta existente
    public String update() {
        try {
            // Cria um objeto ContaModels vazio
            ContaModels conta = new ContaModels();
            Scanner scanner = new Scanner(System.in);

            // Lê o ID da conta que o usuário quer atualizar
            System.out.println("Informe o ID da conta que deseja atualizar: ");
            conta.setId(scanner.nextInt());
            scanner.nextLine();

            // Lê os novos valores da conta do usuário
            System.out.println("Informe o número da conta: ");
            conta.setNumero(scanner.nextLine());

            System.out.println("Informe o dígito da conta: ");
            conta.setDigito(scanner.nextLine());

            System.out.println("Informe o saldo atualizado da conta:");
            conta.setSaldo(scanner.nextDouble());

            System.out.println("Informe o tipo da conta (1 para corrente, 2 para poupança, 3 para salário):");
            int tipoContaInt = scanner.nextInt();
            TipoContaEnum tipoConta = null;

            switch (tipoContaInt) {
                case 1:
                    tipoConta = TipoContaEnum.CORRENTE;
                    break;
                case 2:
                    tipoConta = TipoContaEnum.POUPANCA;
                    break;
                case 3:
                    tipoConta = TipoContaEnum.SALARIO;
                    break;
                default:
                    System.out.println("Tipo de conta inválido!");
                    return "Tipo de conta inválido!";
            }
            conta.setTipoConta(tipoConta);
            scanner.nextLine();

            System.out.println("Informe o RA do aluno que está atualizando essa conta: ");
            conta.setRa(scanner.nextLine());

            System.out.println("Informe o ID da agência atrelada a essa conta: ");
            AgenciaModels agenciaPOJO = new AgenciaModels();
            agenciaPOJO.setId(scanner.nextInt());
            conta.setAgencia(agenciaPOJO);

            System.out.println("Informe o ID da pessoa atrelada a essa conta: ");
            PessoaModels pessoaPOJO = new PessoaModels();
            pessoaPOJO.setId(scanner.nextInt());
            conta.setPessoa(pessoaPOJO);

            // Chama o serviço para atualizar a conta no banco de dados
            ContaService contaService = new ContaService();
            contaService.update(conta);

            String msg = "Conta atualizada com sucesso!";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }
}