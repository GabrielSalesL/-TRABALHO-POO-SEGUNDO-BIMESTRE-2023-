package br.unipar.central.executions;

import br.unipar.central.models.CidadeModels;
import br.unipar.central.models.EnderecoModels;
import br.unipar.central.models.PessoaModels;
import br.unipar.central.services.EnderecoService;
import java.util.List;
import java.util.Scanner;

public class EnderecoExecution {

    // Método para inserir um novo endereço
    public String Insert() {
        try {
            // Criação de um objeto EnderecoModels e de um Scanner para receber as informações do usuário
            EnderecoModels endereco = new EnderecoModels();
            Scanner scanner = new Scanner(System.in);

            // Preenchimento dos campos do objeto EnderecoModels com as informações fornecidas pelo usuário
            System.out.println("Digite o id de endereco: ");
            endereco.setId(scanner.nextInt());
            scanner.nextLine();

            System.out.println("Digite o nome da rua: ");
            endereco.setLogradouro(scanner.nextLine());

            System.out.println("Digite o número da casa: ");
            endereco.setNumero(scanner.nextLine());

            System.out.println("Digite o bairro: ");
            endereco.setBairro(scanner.nextLine());

            System.out.println("Digite o cep: ");
            endereco.setCep(scanner.nextLine());

            System.out.println("Digite o complemento: ");
            endereco.setComplemento(scanner.nextLine());

            System.out.println("Digite o ra do aluno que está inserindo nessa agêencia: ");
            endereco.setRa(scanner.nextLine());

            // Criação de objetos PessoaModels e CidadeModels para associar ao objeto EnderecoModels
            System.out.println("Digite o id de pessoa atrelada a esse endereço: ");
            PessoaModels pessoaPOJO = new PessoaModels();
            pessoaPOJO.setId(scanner.nextInt());
            endereco.setPessoa(pessoaPOJO);

            System.out.println("Digite o id da agencia atrelada a esse endereço: ");
            CidadeModels cidadePOJO = new CidadeModels();
            cidadePOJO.setId(scanner.nextInt());
            endereco.setCidade(cidadePOJO);

            // Criação de um objeto EnderecoService para acessar os métodos de CRUD do endereço
            EnderecoService enderecoService = new EnderecoService();
            enderecoService.insert(endereco);

            // Mensagem de sucesso
            String msg = "Inserido com sucesso";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            // Mensagem de erro em caso de exceção
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

// Método para buscar todos os endereços cadastrados
    public String FindAll() {
        try {
            // Criação de um objeto EnderecoService para acessar os métodos de CRUD do endereço
            EnderecoService enderecoService = new EnderecoService();

            // Chamada do método de busca de todos os endereços
            List<EnderecoModels> procurarPorEndereco = enderecoService.findAll();

            // Criação de um objeto EnderecoModels para acessar o método message()
            EnderecoModels enderecoPOJO = new EnderecoModels();
            enderecoPOJO.message();

            // Mensagem com a lista de todos os endereços encontrados
            String msg = "Todos os itens encontrados " + procurarPorEndereco.toString();
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            // Mensagem de erro em caso de exceção
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

// Método para buscar um endereço específico pelo ID
    public String FindById() {
        try {
            // Criação de um objeto EnderecoService para acessar os métodos de CRUD do endereço
            EnderecoService enderecoService = new EnderecoService();

            // Criação de um objeto EnderecoModels e de um Scanner para receber as informações do usuário
            EnderecoModels endereco = new EnderecoModels();
            Scanner scanner = new Scanner(System.in);

            // Preenchimento do campo ID do objeto EnderecoModels com a informação fornecida pelo usuário
            System.out.println("Digite o ID de endereço para realizar a busca: ");
            int id = scanner.nextInt();
            endereco.setId(id);

            // Criação de um objeto EnderecoModels para acessar o método message()
            EnderecoModels enderecoPOJO = new EnderecoModels();
            enderecoPOJO.message();

            // Mensagem com o endereço encontrado
            String msg = "Item encontrado: " + enderecoService.findById(endereco.getId());
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            // Mensagem de erro em caso de exceção
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

// Método para deletar um endereço pelo ID
    public String DeleteById() {
        try {
            // Criação de um objeto EnderecoService para acessar os métodos de CRUD do endereço
            EnderecoService enderecoService = new EnderecoService();

            // Criação de um objeto EnderecoModels e de um Scanner para receber as informações do usuário
            EnderecoModels endereco = new EnderecoModels();
            Scanner scanner = new Scanner(System.in);

            // Preenchimento do campo ID do objeto EnderecoModels com a informação fornecida pelo usuário
            System.out.println("Digite o ID de endereco: ");
            endereco.setId(scanner.nextInt());

            // Chamada do método de deleção do endereço
            enderecoService.delete(endereco.getId());

            // Mensagem de sucesso
            String msg = "Item deletado com sucesso";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            // Mensagem de erro em caso de exceção
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

// Método para atualizar as informações de um endereço pelo ID
    public String Update() {
        try {
            // Criação de um objeto EnderecoModels e de um Scanner para receber as informações do usuário
            EnderecoModels endereco = new EnderecoModels();
            Scanner scanner = new Scanner(System.in);

            // Preenchimento dos campos do objeto EnderecoModels com as informações fornecidas pelo usuário
            System.out.println("Digite o id de endereco: ");
            endereco.setId(scanner.nextInt());
            scanner.nextLine();

            System.out.println("Digite o nome da rua: ");
            endereco.setLogradouro(scanner.nextLine());

            System.out.println("Digite o número da casa: ");
            endereco.setNumero(scanner.nextLine());

            System.out.println("Digite o bairro: ");
            endereco.setBairro(scanner.nextLine());

            System.out.println("Digite o cep: ");
            endereco.setCep(scanner.nextLine());

            System.out.println("Digite o complemento: ");
            endereco.setComplemento(scanner.nextLine());

            System.out.println("Digite o ra do aluno que está dando update: ");
            endereco.setRa(scanner.nextLine());

            // Criação de objetos PessoaModels e CidadeModels para associar ao objeto EnderecoModels
            System.out.println("Digite o id de pessoa atrelada a esse endereço: ");
            PessoaModels pessoaPOJO = new PessoaModels();
            pessoaPOJO.setId(scanner.nextInt());
            endereco.setPessoa(pessoaPOJO);

            System.out.println("Digite o id da agencia atrelada a esse endereço: ");
            CidadeModels cidadePOJO = new CidadeModels();
            cidadePOJO.setId(scanner.nextInt());
            endereco.setCidade(cidadePOJO);

            // Criação de um objeto EnderecoService para acessar os métodos de CRUD do endereço
            EnderecoService enderecoService = new EnderecoService();

            // Chamada do método de atualização do endereço
            enderecoService.update(endereco);

            // Mensagem de sucesso
            String msg = "Update realizado com sucesso";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            // Mensagem de erro em caso de exceção
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }
}
