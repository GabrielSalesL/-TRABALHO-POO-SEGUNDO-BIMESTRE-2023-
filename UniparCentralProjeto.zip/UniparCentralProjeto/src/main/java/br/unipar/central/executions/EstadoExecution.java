package br.unipar.central.executions;

import br.unipar.central.models.EstadoModels;
import br.unipar.central.models.PaisModels;
import br.unipar.central.services.EstadoService;
import java.util.List;
import java.util.Scanner;

public class EstadoExecution {

    // Método responsável por inserir um novo estado no banco de dados
    public String Insert() {
        try {
            EstadoModels estado = new EstadoModels();
            Scanner scanner = new Scanner(System.in);
            
            // Solicita ao usuário que digite o ID do estado
            System.out.println("Digite o id de estado: ");
            estado.setId(scanner.nextInt());
            scanner.nextLine();

            // Solicita ao usuário que digite o nome do estado
            System.out.println("Digite o nome da estado: ");
            estado.setNome(scanner.nextLine());

            // Solicita ao usuário que digite a sigla do estado
            System.out.println("Digite a sigla da estado: ");
            estado.setSigla(scanner.nextLine());

            // Solicita ao usuário que digite o RA do aluno que está inserindo esse estado
            System.out.println("Digite o ra do aluno que está inserindo esse estado: ");
            estado.setRa(scanner.nextLine());
            
            // Solicita ao usuário que digite o ID do país ao qual o estado pertence
            System.out.println("Digite o id de país atrelado a esse estado: ");
            PaisModels paisPOJO = new PaisModels();
            paisPOJO.setId(scanner.nextInt());
            estado.setPais(paisPOJO);

            // Chama o serviço de Estado para inserir o estado no banco de dados
            EstadoService estadoService = new EstadoService();
            estadoService.insert(estado);
            String msg = "Inserido com sucesso";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    // Método responsável por buscar todos os estados no banco de dados
    public String FindAll() {
        try {
            // Chama o serviço de Estado para buscar todos os estados no banco de dados
            EstadoService estadoService = new EstadoService();
            List<EstadoModels> procurarPorEstado = estadoService.findAll();
            EstadoModels estadoPOJO = new EstadoModels();
            estadoPOJO.message();
            String msg = "Todos os itens encontrados " + procurarPorEstado.toString();
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    // Método responsável por buscar um estado específico no banco de dados
    public String FindById() {
        try {
            EstadoService estadoService = new EstadoService();
            EstadoModels estado = new EstadoModels();
            Scanner scanner = new Scanner(System.in);

            // Solicita ao usuário que digite o ID do estado que deseja buscar
            System.out.println("Digite o ID do estado para realizar a busca: ");
            int id = scanner.nextInt();
            estado.setId(id);
            EstadoModels estadoPOJO = new EstadoModels();
            estadoPOJO.message();
            
            // Chama o serviço de Estado para buscar o estado no banco de dados
            String msg = "Item encontrado: " + estadoService.findById(estado.getId());
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    // Método responsável por deletar um estado específico no banco de dados
    public String DeleteById() {
        try {
            Scanner scanner = new Scanner(System.in);

            EstadoService estadoService = new EstadoService();
            EstadoModels estado = new EstadoModels();

            // Solicita ao usuário que digite o ID do estado que deseja deletar
            System.out.println("Digite o ID de estado: ");
            estado.setId(scanner.nextInt());
            estadoService.delete(estado.getId());
            String msg = "Item deletado com sucesso";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    // Método responsável por atualizar um estado específico no banco de dados
    public String Update() {
        try {
            EstadoModels estado = new EstadoModels();
            Scanner scanner = new Scanner(System.in);
            
            // Solicita ao usuário que digite o ID do estado que deseja atualizar
            System.out.println("Digite o id de estado: ");
            estado.setId(scanner.nextInt());
            scanner.nextLine();

            // Solicita ao usuário que digite o nome do estado atualizado
            System.out.println("Digite o nome da estado: ");
            estado.setNome(scanner.nextLine());

            // Solicita ao usuário que digite a sigla do estado atualizado
            System.out.println("Digite a sigla da estado: ");
            estado.setSigla(scanner.nextLine());

            // Solicita ao usuário que digite o RA do aluno que está atualizando esse estado
            System.out.println("Digite o ra do aluno que está dando update nesse estado: ");
            estado.setRa(scanner.nextLine());
            
            // Solicita ao usuário que digite o ID do país ao qual o estado atualizado pertence
            System.out.println("Digite o id de país atrelado a esse estado: ");
            PaisModels paisPOJO = new PaisModels();
            paisPOJO.setId(scanner.nextInt());
            estado.setPais(paisPOJO);
            
            // Chama o serviço de Estado para atualizar o estado no banco de dados
            EstadoService estadoService = new EstadoService();
            estadoService.update(estado);
            String msg = "Update realizado com sucesso";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }
    
}