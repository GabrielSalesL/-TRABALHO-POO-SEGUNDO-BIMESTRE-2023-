package br.unipar.central.executions;

import br.unipar.central.models.PaisModels;
import br.unipar.central.services.PaisService;
import java.util.List;
import java.util.Scanner;

public class PaisExecution {

    // Método responsável por inserir um novo país no banco de dados
    public String Insert() {
        try {
            PaisModels pais = new PaisModels();
            Scanner scanner = new Scanner(System.in);

            // Solicita ao usuário que digite o ID do país
            System.out.println("Digite o id de país: ");
            pais.setId(scanner.nextInt());
            scanner.nextLine();
            
            // Solicita ao usuário que digite o nome do país
            System.out.println("Digite o nome da país: ");
            pais.setNome(scanner.nextLine());
            
            // Solicita ao usuário que digite a sigla do país
            System.out.println("Digite a sigla da país: ");
            pais.setSigla(scanner.nextLine());
            
            // Solicita ao usuário que digite o RA do aluno que está inserindo esse país
            System.out.println("Digite o ra do aluno que está cadastrando esse país: ");
            pais.setRa(scanner.nextLine());
            
            // Chama o serviço de Pais para inserir o país no banco de dados
            PaisService paisService = new PaisService();
            paisService.insert(pais);
            String msg = "Inserido com sucesso";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    // Método responsável por buscar todos os países no banco de dados
    public String FindAll() {
        try {
            // Chama o serviço de Pais para buscar todos os países no banco de dados
            PaisService paisService = new PaisService();
            List<PaisModels> procurarPorPais = paisService.findAll();
            PaisModels paisPOJO = new PaisModels();
            paisPOJO.message();
            String msg = "Todos os itens encontrados " + procurarPorPais.toString();
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    // Método responsável por buscar um país específico no banco de dados
    public String FindById() {
        try {
            PaisService paisService = new PaisService();
            PaisModels pais = new PaisModels();
            Scanner scanner = new Scanner(System.in);

            // Solicita ao usuário que digite o ID do país que deseja buscar
            System.out.println("Digite o ID de país para realizar a busca: ");
            int id = scanner.nextInt();
            pais.setId(id);
            PaisModels paisPOJO = new PaisModels();
            paisPOJO.message();
            
            // Chama o serviço de Pais para buscar o país no banco de dados
            String msg = "Item encontrado: " + paisService.findById(pais.getId());
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    // Método responsável por deletar um país específico no banco de dados
    public String DeleteById() {
        try {
            Scanner scanner = new Scanner(System.in);

            PaisService paisService = new PaisService();
            PaisModels pais = new PaisModels();

            // Solicita ao usuário que digite o ID do país que deseja deletar
            System.out.println("Digite o ID de pais: ");
            pais.setId(scanner.nextInt());
            paisService.delete(pais.getId());
            String msg = "Item deletado com sucesso";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    // Método responsável por atualizar um país específico no banco de dados
    public String Update() {
        try {
            PaisModels pais = new PaisModels();
            Scanner scanner = new Scanner(System.in);

            // Solicita ao usuário que digite o ID do país que deseja atualizar
            System.out.println("Digite o id de pais: ");
            pais.setId(scanner.nextInt());
            scanner.nextLine();
            
            // Solicita ao usuário que digite o nome do país atualizado
            System.out.println("Digite o nome da pais: ");
            pais.setNome(scanner.nextLine());
            
            // Solicita ao usuário que digite a sigla do país atualizado
            System.out.println("Digite a sigla da pais: ");
            pais.setSigla(scanner.nextLine());
            
            // Solicita ao usuário que digite oRA do aluno que está realizando a atualização
            System.out.println("Digite o ra do aluno que está realizando updata nesse país: ");
            pais.setRa(scanner.nextLine());
            
            // Chama o serviço de Pais para atualizar o país no banco de dados
            PaisService paisService = new PaisService();
            paisService.update(pais);
            String msg = "Update realizado com sucesso";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }
    
}