package br.unipar.central.executions;

import br.unipar.central.models.PessoaFisicaModels;
import br.unipar.central.models.PessoaModels;
import br.unipar.central.services.PessoaFisicaService;
import java.sql.Date;
import java.util.List;
import java.util.Scanner;

public class PessoaFisicaExecution {

    // Método responsável por inserir uma nova pessoa física no banco de dados
    public String Insert() {
        try {
            PessoaFisicaModels pessoaFisica = new PessoaFisicaModels();
            Scanner scanner = new Scanner(System.in);

            // Solicita ao usuário que digite o nome da pessoa física
            System.out.println("Digite o nome da pessoa fisica: ");
            pessoaFisica.setNome(scanner.nextLine());
            
            // Solicita ao usuário que digite o CPF da pessoa física
            System.out.println("Digite o cpf de pessoa fisica: ");
            pessoaFisica.setCpf(scanner.nextLine());
            
            // Solicita ao usuário que digite o RG da pessoa física
            System.out.println("Digite a rg da pessoa fisica: ");
            pessoaFisica.setRg(scanner.nextLine());
            
            // Solicita ao usuário que digite a data de nascimento da pessoa física
            System.out.println("Digite a data de nascimento da pessoa fisica: ");
            System.out.println("Digite dia:");
            int day = scanner.nextInt();
            System.out.println("Digite mês:");
            int month = scanner.nextInt();
            System.out.println("Digite ano:");
            int year = scanner.nextInt();
            Date dataNascimento = new Date(year - 1900, month - 1, day);
            pessoaFisica.setDataNascimento(dataNascimento);

            // Solicita ao usuário que digite o ID da pessoa atrelada a essa pessoa física
            System.out.println("Digite o id da pessoa atrelada a essa pessoa física: ");
            PessoaModels pessoaPOJO = new PessoaModels();
            pessoaPOJO.setId(scanner.nextInt());
            pessoaFisica.setPessoa(pessoaPOJO);

            PessoaFisicaService pessoaFisicaService = new PessoaFisicaService();
            pessoaFisicaService.insert(pessoaFisica);
            String msg = "Inserido com sucesso";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    // Método responsável por buscar todas as pessoas físicas no banco de dados
    public String FindAll() {
        try {
            PessoaFisicaService pessoaFisicaService = new PessoaFisicaService();
            List<PessoaFisicaModels> procurarPorPessoaFisica = pessoaFisicaService.findAll();
            PessoaFisicaModels pessoaFisicaPOJO = new PessoaFisicaModels();
            pessoaFisicaPOJO.message();
            String msg = "Todos os itens encontrados " + procurarPorPessoaFisica.toString();
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    // Método responsável por buscar uma pessoa física específica no banco de dados
    public String FindById() {
        try {
            PessoaFisicaService pessoaFisicaService = new PessoaFisicaService();
            PessoaFisicaModels pessoaFisica = new PessoaFisicaModels();
            Scanner scanner = new Scanner(System.in);

            // Solicita ao usuário que digite o CPF da pessoa física que deseja buscar
            System.out.println("Digite o CPF da pessoa física para realizar a busca: ");
            String cpf = scanner.nextLine();
            pessoaFisica.setCpf(cpf);
            PessoaFisicaModels pessoaFisicaPOJO = new PessoaFisicaModels();
            pessoaFisicaPOJO.message();
            
            // Chama o serviço de Pessoa Física para buscar a pessoa física no banco de dados
            String msg = "Item encontrado: " + pessoaFisicaService.findById(pessoaFisica.getCpf());
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    // Método responsável por deletar uma pessoa física específica no banco de dados
    public String DeleteById() {
        try {
            Scanner scanner = new Scanner(System.in);

            PessoaFisicaService pessoaFisicaService = new PessoaFisicaService();
            PessoaFisicaModels pessoaFisica = new PessoaFisicaModels();

            // Solicita ao usuárioque digite o CPF da pessoa física que deseja deletar
            System.out.println("Digite o CPF de pessoa física: ");
            pessoaFisica.setCpf(scanner.nextLine());
            pessoaFisicaService.delete(pessoaFisica.getCpf());
            String msg = "Item deletado com sucesso";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    // Método responsável por atualizar uma pessoa física existente no banco de dados
    public String Update() {
        try {
            PessoaFisicaModels pessoaFisica = new PessoaFisicaModels();
            Scanner scanner = new Scanner(System.in);

            // Solicita ao usuário que digite o nome da pessoa física
            System.out.println("Digite o nome da pessoa física: ");
            pessoaFisica.setNome(scanner.nextLine());
            
            // Solicita ao usuário que digite o CPF da pessoa física
            System.out.println("Digite o cpf de pessoa física: ");
            pessoaFisica.setCpf(scanner.nextLine());
            
            // Solicita ao usuário que digite o RG da pessoa física
            System.out.println("Digite a rg da pessoa física: ");
            pessoaFisica.setRg(scanner.nextLine());
            
            // Solicita ao usuário que digite a data de nascimento da pessoa física
            System.out.println("Digite a data de nascimento da pessoa física: ");
            System.out.println("Digite dia:");
            int day = scanner.nextInt();
            System.out.println("Digite mês:");
            int month = scanner.nextInt();
            System.out.println("Digite ano:");
            int year = scanner.nextInt();
            Date dataNascimento = new Date(year - 1900, month - 1, day);
            pessoaFisica.setDataNascimento(dataNascimento);

            // Solicita ao usuário que digite o ID da pessoa atrelada a essa pessoa física
            System.out.println("Digite o id da pessoa atrelada a essa pessoa física: ");
            PessoaModels pessoaPOJO = new PessoaModels();
            pessoaPOJO.setId(scanner.nextInt());
            pessoaFisica.setPessoa(pessoaPOJO);
            
            PessoaFisicaService pessoaFisicaService = new PessoaFisicaService();
            pessoaFisicaService.update(pessoaFisica);
            String msg = "Update realizado com sucesso";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

}