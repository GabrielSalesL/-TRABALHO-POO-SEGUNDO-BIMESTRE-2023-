package br.unipar.central.executions;

import br.unipar.central.models.PessoaJuridicaModels;
import br.unipar.central.models.PessoaModels;
import br.unipar.central.services.PessoaJuridicaService;
import java.util.List;
import java.util.Scanner;

public class PessoaJuridicaExecution {

    // Método responsável por inserir uma pessoa jurídica no sistema
    public String Insert() {
        try {
            PessoaJuridicaModels pessoaJuridica = new PessoaJuridicaModels();
            Scanner scanner = new Scanner(System.in);
            
            // Solicita ao usuário que digite a razão social da pessoa jurídica e armazena o valor no objeto pessoaJuridica
            System.out.println("Digite a razão social da pessoa jurídica: ");
            pessoaJuridica.setRazaoSocial(scanner.nextLine());
            
            // Solicita ao usuário que digite o CNPJ da pessoa jurídica e armazena o valor no objeto pessoaJuridica
            System.out.println("Digite o cnpj de pessoa jurídica: ");
            pessoaJuridica.setCNPJ(scanner.nextLine());
            
            // Solicita ao usuário que digite o CNAE da pessoa jurídica e armazena o valor no objeto pessoaJuridica
            System.out.println("Digite o cnae da pessoa jurídica: ");
            pessoaJuridica.setCnaePrincipal(scanner.nextLine());
            
            // Solicita ao usuário que digite o nome fantasia da pessoa jurídica e armazena o valor no objeto pessoaJuridica
            System.out.println("Digite o nome fantasia da pessoa jurídica: ");
            pessoaJuridica.setNomeFantasia(scanner.nextLine());
            
            // Solicita ao usuário que digite o ID da pessoa física atrelada a essa pessoa jurídica e armazena o valor no objeto pessoaPOJO
            System.out.println("Digite o id da pessoa atrelada a essa pessoa jurídica: ");
            PessoaModels pessoaPOJO = new PessoaModels();
            pessoaPOJO.setId(scanner.nextInt());
            pessoaJuridica.setPessoa(pessoaPOJO);

            // Instancia um objeto do tipo PessoaJuridicaService e chama o método insert, passando o objeto pessoaJuridica como parâmetro
            PessoaJuridicaService pessoaJuridicaService = new PessoaJuridicaService();
            pessoaJuridicaService.insert(pessoaJuridica);
            
            // Exibe uma mensagem de sucesso na inserção
            String msg = "Inserido com sucesso";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            // Em caso de erro, exibe a mensagem de erro e retorna a mesma
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    // Método responsável por buscar todas as pessoas jurídicas cadastradas no sistema
    public String FindAll() {
        try {
            // Instancia um objeto do tipo PessoaJuridicaService e chama o método findAll
            PessoaJuridicaService pessoaJuridicaService = new PessoaJuridicaService();
            List<PessoaJuridicaModels> procurarPorPessoaJuridica = pessoaJuridicaService.findAll();
            
            // Instancia um objeto do tipo PessoaJuridicaModels e chama o método message
            PessoaJuridicaModels pessoaJuridicaPOJO = new PessoaJuridicaModels();
            pessoaJuridicaPOJO.message();
            
            // Exibe uma mensagem contendo todas as pessoas jurídicas encontradas
            String msg = "Todos os itens encontrados " + procurarPorPessoaJuridica.toString();
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            // Em caso de erro, exibe a mensagem de erro e retorna a mesma
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    // Método responsável por buscar uma pessoa jurídica específica pelo CNPJ
    public String FindById() {
        try {
            // Instancia um objeto do tipo PessoaJuridicaService e um objeto do tipo PessoaJuridicaModels
            PessoaJuridicaService pessoaJuridicaService = new PessoaJuridicaService();
            PessoaJuridicaModels pessoaJuridica = new PessoaJuridicaModels();
            Scanner scanner = new Scanner(System.in);

            // Solicita ao usuário que digite o CNPJ da pessoa jurídica e armazena o valor no objeto pessoaJuridica
            System.out.println("Digite o CNPJ de  : ");
            String cpf = scanner.nextLine();
            pessoaJuridica.setCNPJ(cpf);
            
            // Instancia um objeto do tipoPessoaJuridicaModels e chama o método message
            PessoaJuridicaModels pessoaJuridicaPOJO = new PessoaJuridicaModels();
            pessoaJuridicaPOJO.message();
            
            // Instancia um objeto do tipo PessoaJuridicaService e chama o método findById, passando o CNPJ da pessoa jurídica como parâmetro
            String msg = "Item encontrado: " + pessoaJuridicaService.findById(pessoaJuridica.getCNPJ());
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            // Em caso de erro, exibe a mensagem de erro e retorna a mesma
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    // Método responsável por deletar uma pessoa jurídica específica pelo CNPJ
    public String DeleteById() {
        try {
            Scanner scanner = new Scanner(System.in);

            // Instancia um objeto do tipo PessoaJuridicaService e um objeto do tipo PessoaJuridicaModels
            PessoaJuridicaService pessoaJuridicaService = new PessoaJuridicaService();
            PessoaJuridicaModels pessoaJuridica = new PessoaJuridicaModels();

            // Solicita ao usuário que digite o CNPJ da pessoa jurídica e armazena o valor no objeto pessoaJuridica
            System.out.println("Digite o CNPJ de pessoaJuridica: ");
            pessoaJuridica.setCNPJ(scanner.nextLine());
            
            // Chama o método delete do objeto pessoaJuridicaService, passando o CNPJ da pessoa jurídica como parâmetro
            pessoaJuridicaService.delete(pessoaJuridica.getCNPJ());
            
            // Exibe uma mensagem de sucesso na deleção
            String msg = "Item deletado com sucesso";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            // Em caso de erro, exibe a mensagem de erro e retorna a mesma
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    // Método responsável por atualizar os dados de uma pessoa jurídica
    public String Update() {
        try {
            PessoaJuridicaModels pessoaJuridica = new PessoaJuridicaModels();
            Scanner scanner = new Scanner(System.in);
            
            // Solicita ao usuário que digite a razão social da pessoa jurídica e armazena o valor no objeto pessoaJuridica
            System.out.println("Digite a razão social da pessoa jurídica: ");
            pessoaJuridica.setRazaoSocial(scanner.nextLine());
            
            // Solicita ao usuário que digite o CNPJ da pessoa jurídica e armazena o valor no objeto pessoaJuridica
            System.out.println("Digite o cnpj de pessoa jurídica: ");
            pessoaJuridica.setCNPJ(scanner.nextLine());
            
            // Solicita ao usuário que digite o CNAE da pessoa jurídica e armazena o valor no objeto pessoaJuridica
            System.out.println("Digite o cnae da pessoa jurídica: ");
            pessoaJuridica.setCnaePrincipal(scanner.nextLine());
            
            // Solicita ao usuário que digite o nome fantasia da pessoa jurídica e armazena o valor no objeto pessoaJuridica
            System.out.println("Digite o nome fantasia da pessoa jurídica: ");
            pessoaJuridica.setNomeFantasia(scanner.nextLine());
            
            // Solicita ao usuário que digite o ID da pessoa física atrelada a essa pessoa jurídica e armazena o valor no objeto pessoaPOJO
            System.out.println("Digite o id da pessoa atrelada a essa pessoa jurídica: ");
            PessoaModels pessoaPOJO = new PessoaModels();
            pessoaPOJO.setId(scanner.nextInt());
            pessoaJuridica.setPessoa(pessoaPOJO);
            
            // Instancia um objeto do tipo PessoaJuridicaService e chama o método update, passando o objeto pessoaJuridica como parâmetro
            PessoaJuridicaService pessoaJuridicaService = new PessoaJuridicaService();
            pessoaJuridicaService.update(pessoaJuridica);
            
            // Exibe uma mensagem de sucesso na atualização
            String msg = "Update realizado com sucesso";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            // Em caso de erro, exibe a mensagem de erro e retorna a mesma
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

}