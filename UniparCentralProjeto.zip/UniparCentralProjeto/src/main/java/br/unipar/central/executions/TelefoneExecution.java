package br.unipar.central.executions;

import br.unipar.central.enums.TipoOperadoraEnum;
import br.unipar.central.models.AgenciaModels;
import br.unipar.central.models.PessoaModels;
import br.unipar.central.models.TelefoneModels;
import br.unipar.central.services.TelefoneService;
import java.util.List;
import java.util.Scanner;

public class TelefoneExecution {

    public String Insert() {
        try {
            TelefoneModels telefone = new TelefoneModels();
            Scanner scanner = new Scanner(System.in);

            System.out.println("Digite o id de telefone: ");
            telefone.setId(scanner.nextInt());
            scanner.nextLine();

            System.out.println("Digite o numero de telefone: ");
            telefone.setNumero(scanner.nextLine());

            System.out.println("Digite a operadora (1 - TIM, 2 - CLARO, 3 - VIVO, 4 - OI, 5 - CORREIOS");
            String tipoContaStr = scanner.next();
            TipoOperadoraEnum tipoOp;

            switch (tipoContaStr) {
                case "1":
                    tipoOp = TipoOperadoraEnum.TIM;
                    break;
                case "2":
                    tipoOp = TipoOperadoraEnum.CLARO;
                    break;
                case "3":
                    tipoOp = TipoOperadoraEnum.VIVO;
                    break;
                case "4":
                    tipoOp = TipoOperadoraEnum.OI;
                    break;
                case "5":
                    tipoOp = TipoOperadoraEnum.CORREIOS;
                    break;
                default:
                    tipoOp = null;
                    break;
            }
            telefone.setOperadora(tipoOp);
            scanner.nextLine();

            System.out.println("Digite o ra do aluno que está cadastrando esse telefone: ");
            telefone.setRa(scanner.nextLine());

            System.out.println("Digite o id de agencia atrelada a esse telefone: ");
            AgenciaModels agenciaPOJO = new AgenciaModels();
            agenciaPOJO.setId(scanner.nextInt());
            telefone.setAgencia(agenciaPOJO);

            System.out.println("Digite o id de pessoa atrelada a esse telefone: ");
            PessoaModels pessoaPOJO = new PessoaModels();
            pessoaPOJO.setId(scanner.nextInt());
            telefone.setPessoa(pessoaPOJO);

            TelefoneService telefoneService = new TelefoneService();
            telefoneService.insert(telefone);
            String msg = "Inserido com sucesso";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    public String FindAll() {
        try {
            TelefoneService telefoneService = new TelefoneService();
            List<TelefoneModels> procurarPorTelefone = telefoneService.findAll();
            TelefoneModels telefonePOJO = new TelefoneModels();
            telefonePOJO.message();
            String msg = "Todos os itens encontrados " + procurarPorTelefone.toString();
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    public String FindById() {
        try {
            TelefoneService telefoneService = new TelefoneService();
            TelefoneModels telefone = new TelefoneModels();
            Scanner scanner = new Scanner(System.in);

            System.out.println("Digite o ID de telefone para realizar a busca: ");
            int id = scanner.nextInt();
            telefone.setId(id);
            TelefoneModels telefonePOJO = new TelefoneModels();
            telefonePOJO.message();
            String msg = "Item encontrado: " + telefoneService.findById(telefone.getId());
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    public String DeleteById() {
        try {
            Scanner scanner = new Scanner(System.in);

            TelefoneService telefoneService = new TelefoneService();
            TelefoneModels telefone = new TelefoneModels();

            System.out.println("Digite o ID de telefone: ");
            telefone.setId(scanner.nextInt());
            telefoneService.delete(telefone.getId());
            String msg = "Item deletado com sucesso";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }

    public String Update() {
        try {
            TelefoneModels telefone = new TelefoneModels();
            Scanner scanner = new Scanner(System.in);

            System.out.println("Digite o id de telefone: ");
            telefone.setId(scanner.nextInt());
            scanner.nextLine();

            System.out.println("Digite o numero de telefone: ");
            telefone.setNumero(scanner.nextLine());

            System.out.println("Digite a operadora (1 - TIM, 2 - CLARO, 3 - VIVO, 4 - OI, 5 - CORREIOS");
            String tipoContaStr = scanner.next();
            TipoOperadoraEnum tipoOp;

            switch (tipoContaStr) {
                case "1":
                    tipoOp = TipoOperadoraEnum.TIM;
                    break;
                case "2":
                    tipoOp = TipoOperadoraEnum.CLARO;
                    break;
                case "3":
                    tipoOp = TipoOperadoraEnum.VIVO;
                    break;
                case "4":
                    tipoOp = TipoOperadoraEnum.OI;
                    break;
                case "5":
                    tipoOp = TipoOperadoraEnum.CORREIOS;
                    break;
                default:
                    tipoOp = null;
                    break;
            }
            telefone.setOperadora(tipoOp);
            scanner.nextLine();

            System.out.println("Digite o ra do aluno que está realizando update nesse telefone: ");
            telefone.setRa(scanner.nextLine());

            System.out.println("Digite o id de agencia atrelada a esse telefone: ");
            AgenciaModels agenciaPOJO = new AgenciaModels();
            agenciaPOJO.setId(scanner.nextInt());
            telefone.setAgencia(agenciaPOJO);

            System.out.println("Digite o id de pessoa atrelada a esse telefone: ");
            PessoaModels pessoaPOJO = new PessoaModels();
            pessoaPOJO.setId(scanner.nextInt());
            telefone.setPessoa(pessoaPOJO);

            TelefoneService telefoneService = new TelefoneService();
            telefoneService.update(telefone);
            String msg = "Update realizado com sucesso";
            System.out.println(msg);
            return msg;
        } catch (Exception ex) {
            String msg = ex.getMessage();
            System.out.println(msg);
            return msg;
        }
    }
}
