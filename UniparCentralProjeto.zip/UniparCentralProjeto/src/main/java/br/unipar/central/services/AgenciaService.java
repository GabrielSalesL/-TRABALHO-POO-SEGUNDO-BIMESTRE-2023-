package br.unipar.central.services;

import br.unipar.central.DAO.AgenciaDAO;
import br.unipar.central.DAO.PaisDAO;
import br.unipar.central.exceptions.CampoEspecificoNaoInformadoException;
import br.unipar.central.exceptions.EntidadeOuClasseEmBrancoOuNaoInformadaException;
import br.unipar.central.exceptions.TamanhoMaximoDoCampoExcedidoException;
import br.unipar.central.exceptions.ValorInvalidoException;
import br.unipar.central.models.AgenciaModels;
import br.unipar.central.models.PaisModels;
import java.sql.SQLException;
import java.util.List;

public class AgenciaService {

    // Método responsável por validar uma instância da classe AgenciaModels
    public void validar(AgenciaModels agencia) throws EntidadeOuClasseEmBrancoOuNaoInformadaException,
            CampoEspecificoNaoInformadoException,
            TamanhoMaximoDoCampoExcedidoException,
            ValorInvalidoException {

        // Conversão dos atributos código e dígito para strings, para facilitar as validações
        String codStr = String.valueOf(agencia.getCodigo());
        String digitoStr = String.valueOf(agencia.getDigito());

        // Verifica se a classe da instância é nula
        if (agencia.getClass() == null) {
            throw new EntidadeOuClasseEmBrancoOuNaoInformadaException("agência");
        }

        // Verifica se o atributo código da instância é nulo ou vazio
        if (agencia.getCodigo() == null || agencia.getCodigo().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("código");
        }

        // Verifica se o atributo código da instância contém apenas números
        if (!codStr.matches("\\d+")) {
            throw new ValorInvalidoException("código");
        }

        // Verifica se o atributo razão social da instância é nulo, vazio ou em branco
        if (agencia.getRazaoSocial() == null || agencia.getRazaoSocial().isEmpty() || agencia.getRazaoSocial().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("razão social da agência");
        }

        // Verifica se o atributo razão social da instância não ultrapassa o tamanho máximo permitido
        if (agencia.getRazaoSocial().length() > 60) {
            throw new TamanhoMaximoDoCampoExcedidoException("razão social da agência", 60);
        }

        // Verifica se o atributo dígito da instância é nulo, vazio ou em branco
        if (agencia.getDigito() == null || agencia.getDigito().isEmpty() || agencia.getDigito().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("dígito");
        }

        // Verifica se o atributo dígito da instância não ultrapassa o tamanho máximo permitido
        if (agencia.getDigito().length() == 3) {
            throw new TamanhoMaximoDoCampoExcedidoException("dígito", 3);
        }

        // Verifica se o atributo dígito da instância contém apenas números
        if (!digitoStr.matches("\\d+")) {
            throw new ValorInvalidoException("dígito");
        }

        // Verifica se o atributo ra da instância é nulo, vazio ou em branco
        if (agencia.getRa() == null || agencia.getRa().isEmpty() || agencia.getRa().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("ra");
        }

        // Verifica se o atributo ra da instância não ultrapassa o tamanho máximo permitido
        if (agencia.getRa().length() > 8) {
            throw new TamanhoMaximoDoCampoExcedidoException("ra", 8);
        }

        // Verifica se o atributo cnpj da instância é nulo, vazio ou em branco
        if (agencia.getCnpj() == null || agencia.getRa().isEmpty() || agencia.getRa().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("cnpj");
        }

        // Verifica se o atributo cnpj da instância não ultrapassa o tamanho máximo permitido
        if (agencia.getCnpj().length() == 14) {
            throw new TamanhoMaximoDoCampoExcedidoException("cnpj", 14);
        }

        // Verificase o atributo banco da instância não é nulo
        if (agencia.getBanco() == null) {
            throw new EntidadeOuClasseEmBrancoOuNaoInformadaException("banco");
        }

    }

    // Método responsável por buscar todas as agências do banco de dados
    public List<AgenciaModels> findAll() throws SQLException {

        AgenciaDAO agenciaDAO = new AgenciaDAO();
        List<AgenciaModels> resultado = agenciaDAO.findAll();

        return resultado;
    }

    // Método responsável por buscar uma agência específica pelo seu id no banco de dados
    public AgenciaModels findById(int id) throws SQLException, TamanhoMaximoDoCampoExcedidoException, Exception {

        // Verifica se o id informado é válido
        if (id <= 0) {
            throw new TamanhoMaximoDoCampoExcedidoException("id", 1);
        }

        AgenciaDAO agenciaDAO = new AgenciaDAO();
        AgenciaModels retorno = agenciaDAO.findById(id);

        // Verifica se a agência com o id informado foi encontrada no banco de dados
        if (retorno == null) {
            throw new Exception("Não foi possível encontrar uma agência com o id: " + id + " informado");
        }

        return agenciaDAO.findById(id);
    }

    // Método responsável por inserir uma nova agência no banco de dados
    public void insert(AgenciaModels agencia) throws SQLException, EntidadeOuClasseEmBrancoOuNaoInformadaException, CampoEspecificoNaoInformadoException, TamanhoMaximoDoCampoExcedidoException, ValorInvalidoException {
        validar(agencia); // Valida a instância da agência antes de inseri-la no banco de dados
        AgenciaDAO agenciaDAO = new AgenciaDAO();
        agenciaDAO.insert(agencia);
    }

    // Método responsável por atualizar uma agência existente no banco de dados
    public void update(AgenciaModels agencia) throws SQLException, EntidadeOuClasseEmBrancoOuNaoInformadaException, CampoEspecificoNaoInformadoException, TamanhoMaximoDoCampoExcedidoException, ValorInvalidoException {
        validar(agencia); // Valida a instância da agência antes de atualizá-la no banco de dados
        AgenciaDAO agenciaDAO = new AgenciaDAO();
        agenciaDAO.update(agencia);
    }

    // Método responsável por excluir uma agência do banco de dados pelo seu id
    public void delete(int id) throws SQLException {
        AgenciaDAO agenciaDAO = new AgenciaDAO();
        agenciaDAO.delete(id);

    }
}
