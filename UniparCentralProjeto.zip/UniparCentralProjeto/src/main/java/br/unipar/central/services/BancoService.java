package br.unipar.central.services;

import br.unipar.central.DAO.AgenciaDAO;
import br.unipar.central.DAO.BancoDAO;
import br.unipar.central.exceptions.CampoEspecificoNaoInformadoException;
import br.unipar.central.exceptions.EntidadeOuClasseEmBrancoOuNaoInformadaException;
import br.unipar.central.exceptions.TamanhoMaximoDoCampoExcedidoException;
import br.unipar.central.exceptions.ValorInvalidoException;
import br.unipar.central.models.AgenciaModels;
import br.unipar.central.models.BancoModels;
import java.sql.SQLException;
import java.util.List;

public class BancoService {

    // Método para validar os dados de um objeto BancoModels
    public void validar(BancoModels banco) throws EntidadeOuClasseEmBrancoOuNaoInformadaException,
            CampoEspecificoNaoInformadoException,
            TamanhoMaximoDoCampoExcedidoException,
            ValorInvalidoException {

        String codStr = String.valueOf(banco.getId());

        // Verifica se o objeto BancoModels é nulo
        if (banco == null) {
            throw new EntidadeOuClasseEmBrancoOuNaoInformadaException("banco");
        }

        // Verifica se o ID do banco é igual a zero
        if (banco.getId() == 0) {
            throw new CampoEspecificoNaoInformadoException("código");
        }

        // Verifica se o ID do banco é um número válido
        if (!codStr.matches("\\d+")) {
            throw new ValorInvalidoException("código");
        }

        // Verifica se o nome do banco foi informado
        if (banco.getNome() == null
                || banco.getNome().isEmpty()
                || banco.getNome().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("nome do banco");
        }

        // Verifica se o nome do banco não excede o tamanho máximo permitido
        if ((banco.getNome().length() > 60)) {
            throw new TamanhoMaximoDoCampoExcedidoException("nome do banco", 60);
        }

        // Verifica se o RA do banco foi informado
        if (banco.getRa() == null
                || banco.getRa().isEmpty()
                || banco.getRa().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("ra");
        }

        // Verifica se o RA do banco não excede o tamanho máximo permitido
        if ((banco.getRa().length() > 8)) {
            throw new TamanhoMaximoDoCampoExcedidoException("ra", 8);
        }
    }

    // Método para buscar todos os bancos no sistema
    public List<BancoModels> findAll() throws SQLException {

        BancoDAO bancoDAO = new BancoDAO();
        List<BancoModels> resultado = bancoDAO.findAll();

        return resultado;
    }

    // Método para buscar um banco por ID no sistema
    public BancoModels findById(int id) throws SQLException, TamanhoMaximoDoCampoExcedidoException, Exception {

        // Verifica se o ID informado é válido
        if (id <= 0) {
            throw new TamanhoMaximoDoCampoExcedidoException("id", 1);
        }

        BancoDAO bancoDAO = new BancoDAO();
        BancoModels retorno = bancoDAO.findById(id);

        // Verifica se o banco com o ID informado foi encontrado
        if (retorno == null) {
            throw new Exception("Não foi possível encontrar um país com o id: " + id + " informado");
        }

        return bancoDAO.findById(id);
    }

    // Método para inserir um novo banco no sistema
    public void insert(BancoModels banco) throws SQLException, EntidadeOuClasseEmBrancoOuNaoInformadaException, CampoEspecificoNaoInformadoException, TamanhoMaximoDoCampoExcedidoException, ValorInvalidoException {
        validar(banco);
        BancoDAO bancoDAO = new BancoDAO();
        bancoDAO.insert(banco);
    }

    // Método para atualizar um banco existente no sistema
    public void update(BancoModels banco) throws SQLException, EntidadeOuClasseEmBrancoOuNaoInformadaException, CampoEspecificoNaoInformadoException, TamanhoMaximoDoCampoExcedidoException, ValorInvalidoException {
        validar(banco);
        BancoDAO bancoDAO = new BancoDAO();
        bancoDAO.update(banco);
    }

    // Método para deletar um banco por ID no sistema
    public void delete(int id) throws SQLException {
        BancoDAO bancoDAO = new BancoDAO();
        bancoDAO.delete(id);

    }
}
