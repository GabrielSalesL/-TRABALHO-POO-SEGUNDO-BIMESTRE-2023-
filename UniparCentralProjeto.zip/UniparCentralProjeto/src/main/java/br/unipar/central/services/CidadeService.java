package br.unipar.central.services;

import br.unipar.central.DAO.CidadeDAO;
import br.unipar.central.DAO.PaisDAO;
import br.unipar.central.exceptions.CampoEspecificoNaoInformadoException;
import br.unipar.central.exceptions.EntidadeOuClasseEmBrancoOuNaoInformadaException;
import br.unipar.central.exceptions.TamanhoMaximoDoCampoExcedidoException;
import br.unipar.central.exceptions.ValorInvalidoException;
import br.unipar.central.models.CidadeModels;
import br.unipar.central.models.PaisModels;
import java.sql.SQLException;
import java.util.List;

public class CidadeService {

    // Método para validar os dados de um objeto CidadeModels
    public void validar(CidadeModels cidade) throws
            EntidadeOuClasseEmBrancoOuNaoInformadaException,
            CampoEspecificoNaoInformadoException,
            TamanhoMaximoDoCampoExcedidoException,
            ValorInvalidoException {

        String idStr = String.valueOf(cidade.getId());

        // Verifica se o objeto CidadeModels é nulo
        if (cidade == null) {
            throw new EntidadeOuClasseEmBrancoOuNaoInformadaException("cidade");
        }

        // Verifica se o ID da cidade é igual a zero
        if (cidade.getId() == 0) {
            throw new CampoEspecificoNaoInformadoException("id");
        }

        // Verifica se o ID da cidade é um número válido
        if (!idStr.matches("\\d+")) {
            throw new ValorInvalidoException("id");
        }

        // Verifica se o nome da cidade foi informado
        if (cidade.getNome() == null
                || cidade.getNome().isEmpty()
                || cidade.getNome().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("nome da cidade");
        }

        // Verifica se o nome da cidade não excede o tamanho máximo permitido
        if ((cidade.getNome().length() > 30)) {
            throw new TamanhoMaximoDoCampoExcedidoException("nome da cidade", 30);
        }

        // Verifica se o RA da cidade foi informado
        if (cidade.getRa() == null
                || cidade.getRa().isEmpty()
                || cidade.getRa().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("ra");
        }

        // Verifica se o RA da cidade não excede o tamanho máximo permitido
        if ((cidade.getRa().length() > 8)) {
            throw new TamanhoMaximoDoCampoExcedidoException("ra", 8);
        }

    }

    // Método para buscar todas as cidades no sistema
    public List<CidadeModels> findAll() throws SQLException {

        CidadeDAO cidadeDAO = new CidadeDAO();
        List<CidadeModels> resultado = cidadeDAO.findAll();

        return resultado;
    }

    // Método para buscar uma cidade por ID no sistema
    public CidadeModels findById(int id) throws SQLException, TamanhoMaximoDoCampoExcedidoException, Exception {

        // Verifica se o ID informado é válido
        if (id <= 0) {
            throw new TamanhoMaximoDoCampoExcedidoException("id", 1);
        }

        CidadeDAO cidadeDAO = new CidadeDAO();
        CidadeModels retorno = cidadeDAO.findById(id);

        // Verifica se a cidade com o ID informado foi encontrada
        if (retorno == null) {
            throw new Exception("Não foi possível encontrar uma cidade com o id: " + id + " informado");
        }

        return cidadeDAO.findById(id);
    }

    // Método para inserir uma nova cidade no sistema
    public void insert(CidadeModels cidade) throws SQLException, EntidadeOuClasseEmBrancoOuNaoInformadaException, CampoEspecificoNaoInformadoException, TamanhoMaximoDoCampoExcedidoException, ValorInvalidoException {
        validar(cidade);
        CidadeDAO cidadeDAO = new CidadeDAO();
        cidadeDAO.insert(cidade);
    }

    // Método para atualizar uma cidade existente no sistema
    public void update(CidadeModels cidade) throws SQLException, EntidadeOuClasseEmBrancoOuNaoInformadaException, CampoEspecificoNaoInformadoException, TamanhoMaximoDoCampoExcedidoException, ValorInvalidoException {
        validar(cidade);
        CidadeDAO cidadeDAO = new CidadeDAO();
        cidadeDAO.update(cidade);
    }

    // Método para deletar uma cidade por ID no sistema
    public void delete(int id) throws SQLException {
        CidadeDAO cidadeDAO = new CidadeDAO();
        cidadeDAO.delete(id);

    }
}
