package br.unipar.central.services;

import br.unipar.central.DAO.ContaDAO;
import br.unipar.central.exceptions.CampoEspecificoNaoInformadoException;
import br.unipar.central.exceptions.EntidadeOuClasseEmBrancoOuNaoInformadaException;
import br.unipar.central.exceptions.SaldoZeradoException;
import br.unipar.central.exceptions.TamanhoMaximoDoCampoExcedidoException;
import br.unipar.central.exceptions.ValorInvalidoException;
import br.unipar.central.models.ContaModels;
import java.sql.SQLException;
import java.util.List;

public class ContaService {
// Método que realiza a validação dos dados da conta

    public void validar(ContaModels conta) throws
            EntidadeOuClasseEmBrancoOuNaoInformadaException, // Exceção lançada quando a entidade ou classe está em branco ou não foi informada
            CampoEspecificoNaoInformadoException, // Exceção lançada quando um campo específico não foi informado
            TamanhoMaximoDoCampoExcedidoException, // Exceção lançada quando o tamanho máximo de um campo foi excedido
            ValorInvalidoException, // Exceção lançada quando um valor é inválido
            SaldoZeradoException { // Exceção lançada quando o saldo da conta é zerado

        // Converte o id da conta para string
        String idStr = String.valueOf(conta.getId());

        // Verifica se a conta é nula
        if (conta == null) {
            throw new EntidadeOuClasseEmBrancoOuNaoInformadaException("pais");
        }

        // Verifica se o id da conta é igual a zero
        if (conta.getId() == 0) {
            throw new CampoEspecificoNaoInformadoException("código do país");
        }

        // Verifica se o id da conta é composto apenas por dígitos
        if (!idStr.matches("\\d+")) {
            throw new ValorInvalidoException("código do país");
        }

        // Verifica se o número da conta é nulo, vazio ou em branco
        if (conta.getNumero() == null
                || conta.getNumero().isEmpty()
                || conta.getNumero().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("numero da conta");
        }

        // Verifica se o tamanho do número da conta é maior que 10 caracteres
        if ((conta.getNumero().length() > 10)) {
            throw new TamanhoMaximoDoCampoExcedidoException("numero da conta", 10);
        }

        // Verifica se o dígito da conta é nulo, vazio ou em branco
        if (conta.getDigito() == null
                || conta.getDigito().isEmpty()
                || conta.getDigito().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("dígito da conta");
        }

        // Verifica se o tamanho do dígito da conta é maior que 1 caractere
        if ((conta.getDigito().length() > 1)) {
            throw new TamanhoMaximoDoCampoExcedidoException("dígito da conta", 1);
        }

        // Verifica se o saldo da conta é menor que zero ou maior que zero
        if (conta.getSaldo() < 0 || conta.getSaldo() > 0) {
            throw new SaldoZeradoException("saldo em conta");
        }

        // Verifica se o tipo da conta é nulo
        if (conta.getTipoConta() == null) {
            throw new CampoEspecificoNaoInformadoException("tipo da conta");
        }

        // Verifica se o RA é nulo, vazio ou em branco
        if (conta.getRa() == null
                || conta.getRa().isEmpty()
                || conta.getRa().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("ra");
        }

        // Verifica se o tamanho do RA é maior que 8 caracteres
        if ((conta.getRa().length() > 8)) {
            throw new TamanhoMaximoDoCampoExcedidoException("ra", 8);
        }

        // Verifica se a agência da conta é nula
        if (conta.getAgencia() == null) {
            throw new EntidadeOuClasseEmBrancoOuNaoInformadaException("agência");
        }

        // Verifica se a pessoa da conta é nula
        if (conta.getPessoa() == null) {
            throw new EntidadeOuClasseEmBrancoOuNaoInformadaException("pessoa");
        }
    }

    //......
    public void validarUpdate(ContaModels conta) throws EntidadeOuClasseEmBrancoOuNaoInformadaException,
            CampoEspecificoNaoInformadoException,
            TamanhoMaximoDoCampoExcedidoException,
            ValorInvalidoException {

        // Verifica se a conta não é nula
        if (conta == null) {
            throw new EntidadeOuClasseEmBrancoOuNaoInformadaException("pais");
        }

        // Verifica se o código do país foi informado
        if (conta.getId() == 0) {
            throw new CampoEspecificoNaoInformadoException("código do país");
        }

        // Verifica se o código do país é um valor numérico
        String idStr = String.valueOf(conta.getId());
        if (!idStr.matches("\\d+")) {
            throw new ValorInvalidoException("código do país");
        }

        // Verifica se o número da conta foi informado
        if (conta.getNumero() == null
                || conta.getNumero().isEmpty()
                || conta.getNumero().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("numero da conta");
        }

        // Verifica se o número da conta não excede o tamanho máximo permitido
        if ((conta.getNumero().length() > 10)) {
            throw new TamanhoMaximoDoCampoExcedidoException("numero da conta", 10);
        }

        // Verifica se o dígito da conta foi informado
        if (conta.getDigito() == null
                || conta.getDigito().isEmpty()
                || conta.getDigito().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("dígito da conta");
        }

        // Verifica se o dígito da conta não excede o tamanho máximo permitido
        if ((conta.getDigito().length() > 1)) {
            throw new TamanhoMaximoDoCampoExcedidoException("dígito da conta", 1);
        }

        // Verifica se o tipo da conta foi informado
        if (conta.getTipoConta() == null) {
            throw new CampoEspecificoNaoInformadoException("tipo da conta");
        }

        // Verifica se o RA foi informado
        if (conta.getRa() == null
                || conta.getRa().isEmpty()
                || conta.getRa().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("ra");
        }

        // Verifica se o RA não excede o tamanho máximo permitido
        if ((conta.getRa().length() > 8)) {
            throw new TamanhoMaximoDoCampoExcedidoException("ra", 8);
        }

        // Verifica se a agência foi informada
        if (conta.getAgencia() == null) {
            throw new EntidadeOuClasseEmBrancoOuNaoInformadaException("agência");
        }

        // Verifica se a pessoa foi informada
        if (conta.getPessoa() == null) {
            throw new EntidadeOuClasseEmBrancoOuNaoInformadaException("pessoa");
        }

    }

    // Busca todas as contas cadastradas no banco de dados
    public List<ContaModels> findAll() throws SQLException {

        ContaDAO contaDAO = new ContaDAO();
        List<ContaModels> resultado = contaDAO.findAll();

        return resultado;
    }

    // Busca uma conta específica no banco de dados pelo seu ID
    public ContaModels findById(int id) throws SQLException, TamanhoMaximoDoCampoExcedidoException, Exception {

        // Verifica se o ID informado é válido
        if (id <= 0) {
            throw new TamanhoMaximoDoCampoExcedidoException("id", 1);
        }

        ContaDAO contaDAO = new ContaDAO();
        ContaModels retorno = contaDAO.findById(id);

        // Verifica se a conta foi encontrada
        if (retorno == null) {
            throw new Exception("Não foi possível encontrar um país com o id: " + id + " informado");
        }

        return contaDAO.findById(id);
    }

    // Insere uma nova conta no banco de dados
    public void insert(ContaModels conta) throws SQLException, EntidadeOuClasseEmBrancoOuNaoInformadaException, CampoEspecificoNaoInformadoException, TamanhoMaximoDoCampoExcedidoException, ValorInvalidoException, SaldoZeradoException {
        // Valida os campos da conta
        validar(conta);

        ContaDAO contaDAO = new ContaDAO();
        contaDAO.insert(conta);
    }

    // Atualiza uma conta existente no banco de dados
    public void update(ContaModels conta) throws SQLException, EntidadeOuClasseEmBrancoOuNaoInformadaException, CampoEspecificoNaoInformadoException, TamanhoMaximoDoCampoExcedidoException, ValorInvalidoException, SaldoZeradoException {
        // Valida os campos da conta antes de atualizá-la
        validarUpdate(conta);

        ContaDAO contaDAO = new ContaDAO();
        contaDAO.update(conta);
    }

    // Deleta uma conta do banco de dados pelo seu ID
    public void delete(int id) throws SQLException {
        ContaDAO contaDAO = new ContaDAO();
        contaDAO.delete(id);
    }
}
