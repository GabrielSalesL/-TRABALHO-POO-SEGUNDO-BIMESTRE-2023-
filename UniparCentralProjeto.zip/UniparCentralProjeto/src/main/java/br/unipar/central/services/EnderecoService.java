package br.unipar.central.services;

import br.unipar.central.DAO.EnderecoDAO;
import br.unipar.central.DAO.PaisDAO;
import br.unipar.central.exceptions.CampoEspecificoNaoInformadoException;
import br.unipar.central.exceptions.EntidadeOuClasseEmBrancoOuNaoInformadaException;
import br.unipar.central.exceptions.TamanhoMaximoDoCampoExcedidoException;
import br.unipar.central.exceptions.ValorInvalidoException;
import br.unipar.central.models.EnderecoModels;
import br.unipar.central.models.PaisModels;
import java.sql.SQLException;
import java.util.List;

public class EnderecoService {

    // Método responsável por validar os campos do objeto EnderecoModels
    public void validar(EnderecoModels endereco) throws
            EntidadeOuClasseEmBrancoOuNaoInformadaException,
            CampoEspecificoNaoInformadoException,
            TamanhoMaximoDoCampoExcedidoException,
            ValorInvalidoException {

        // Converte o id do objeto para string para poder validá-lo
        String idStr = String.valueOf(endereco.getId());

        // Verifica se o objeto endereco é nulo
        if (endereco == null) {
            throw new EntidadeOuClasseEmBrancoOuNaoInformadaException("endereco");
        }

        // Verifica se o id do objeto é zero
        if (endereco.getId() == 0) {
            throw new CampoEspecificoNaoInformadoException("id");
        }

        // Verifica se o id do objeto é um número
        if (!idStr.matches("\\d+")) {
            throw new ValorInvalidoException("id");
        }

        // Verifica se o logradouro do objeto foi preenchido
        if (endereco.getLogradouro() == null
                || endereco.getLogradouro().isEmpty()
                || endereco.getLogradouro().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("nome da rua");
        }

        // Verifica se o tamanho do logradouro não excede o limite de 60 caracteres
        if ((endereco.getLogradouro().length() > 60)) {
            throw new TamanhoMaximoDoCampoExcedidoException("nome da rua", 60);
        }

        // Verifica se o número do objeto foi preenchido
        if (endereco.getNumero() == null
                || endereco.getNumero().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("número da casa");
        }

        // Verifica se o tamanho do número não excede o limite de 10 caracteres
        if ((endereco.getNumero().length() > 10)) {
            throw new TamanhoMaximoDoCampoExcedidoException("número da casa", 10);
        }

        // Verifica se o bairro do objeto foi preenchido
        if (endereco.getBairro() == null
                || endereco.getBairro().isEmpty()
                || endereco.getBairro().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("nome do bairro");
        }

        // Verifica se o tamanho do bairro não excede o limite de 30 caracteres
        if ((endereco.getBairro().length() == 30)) {
            throw new TamanhoMaximoDoCampoExcedidoException("nome do bairro", 30);
        }

        // Verifica se o CEP do objeto foi preenchido
        if (endereco.getCep() == null
                || endereco.getCep().isEmpty()
                || endereco.getCep().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("número do cep");
        }

        // Verifica se o tamanho do CEP não excede o limite de 9 caracteres
        if ((endereco.getCep().length() > 9)) {
            throw new TamanhoMaximoDoCampoExcedidoException("número do cep", 9);
        }

        // Verifica se o complemento do objeto foi preenchido
        if (endereco.getComplemento() == null
                || endereco.getComplemento().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("complemento");
        }

        // Verifica se o tamanho do complemento não excede o limite de 255 caracteres
        if ((endereco.getComplemento().length() == 255)) {
            throw new TamanhoMaximoDoCampoExcedidoException("complemento", 255);
        }

        // Verifica se o RA do objeto foi preenchido
        if (endereco.getRa() == null
                || endereco.getRa().isEmpty()
                || endereco.getRa().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("ra");
        }

        // Verifica se o tamanho do RA não excede o limite de 8 caracteres
        if ((endereco.getRa().length() > 8)) {
            throw new TamanhoMaximoDoCampoExcedidoException("ra", 8);
        }

        // Verifica se a pessoa do objeto foi informada
        if (endereco.getPessoa() == null) {
            throw new EntidadeOuClasseEmBrancoOuNaoInformadaException("pessoa");
        }

        // Verifica se a cidade do objeto foi informada
        if (endereco.getCidade() == null) {
            throw new EntidadeOuClasseEmBrancoOuNaoInformadaException("cidade");
        }

    }

    // Método responsável por buscar todos os endereços cadastrados
    public List<EnderecoModels> findAll() throws SQLException {

        // Cria uma instância do DAO de Endereço
        EnderecoDAO enderecoDAO = new EnderecoDAO();

        // Chama o método findAll do DAO para buscar os endereços
        List<EnderecoModels> resultado = enderecoDAO.findAll();

        // Retorna o resultado da busca
        return resultado;
    }

    // Método responsável por buscar um endereço pelo id
    public EnderecoModels findById(int id) throws SQLException, TamanhoMaximoDoCampoExcedidoException, Exception {

        // Verifica se o id informado é válido
        if (id <= 0) {
            throw new TamanhoMaximoDoCampoExcedidoException("id", 1);
        }

        // Cria uma instância do DAO de Endereço
        EnderecoDAO enderecoDAO = new EnderecoDAO();

        // Chama o método findById do DAO para buscar o endereço
        EnderecoModels retorno = enderecoDAO.findById(id);

        // Se o retorno for nulo, lança uma exceção informando que não foi possível encontrar o endereço
        if (retorno == null) {
            throw new Exception("Não foi possível encontrar um país com o id: " + id + " informado");
        }

        // Retorna o endereço encontrado
        return enderecoDAO.findById(id);
    }

    // Método responsável por inserir um novo endereço
    public void insert(EnderecoModels endereco) throws SQLException, EntidadeOuClasseEmBrancoOuNaoInformadaException, CampoEspecificoNaoInformadoException, TamanhoMaximoDoCampoExcedidoException, ValorInvalidoException {
        // Valida os campos do objeto EnderecoModels
        validar(endereco);

        // Cria uma instância do DAO de Endereço
        EnderecoDAO enderecoDAO = new EnderecoDAO();

        // Chama o método insert do DAO para inserir o endereço
        enderecoDAO.insert(endereco);
    }

    // Método responsável por atualizar um endereço existente
    public void update(EnderecoModels endereco) throws SQLException, EntidadeOuClasseEmBrancoOuNaoInformadaException, CampoEspecificoNaoInformadoException, TamanhoMaximoDoCampoExcedidoException, ValorInvalidoException {
        // Valida os campos do objeto EnderecoModels
        validar(endereco);

        // Cria uma instância do DAO de Endereço
        EnderecoDAO enderecoDAO = new EnderecoDAO();

        // Chama o método update do DAO para atualizar o endereço
        enderecoDAO.update(endereco);
    }

    // Método responsável por excluir um endereço pelo id
    public void delete(int id) throws SQLException {
        // Cria uma instância do DAO de Endereço
        EnderecoDAO enderecoDAO = new EnderecoDAO();

        // Chama o método delete do DAO para excluir o endereço
        enderecoDAO.delete(id);
    }
}