package br.unipar.central.services;

import br.unipar.central.DAO.EstadoDAO;
import br.unipar.central.DAO.PaisDAO;
import br.unipar.central.exceptions.CampoEspecificoNaoInformadoException;
import br.unipar.central.exceptions.EntidadeOuClasseEmBrancoOuNaoInformadaException;
import br.unipar.central.exceptions.TamanhoMaximoDoCampoExcedidoException;
import br.unipar.central.exceptions.ValorInvalidoException;
import br.unipar.central.models.EstadoModels;
import br.unipar.central.models.PaisModels;
import java.sql.SQLException;
import java.util.List;

public class EstadoService {
    
public void validar(EstadoModels estado) throws
        EntidadeOuClasseEmBrancoOuNaoInformadaException,
        CampoEspecificoNaoInformadoException,
        TamanhoMaximoDoCampoExcedidoException,
        ValorInvalidoException {

    // Conversão do id para string para validação
    String idStr = String.valueOf(estado.getId());

    // Verifica se o objeto EstadoModels é nulo
    if (estado == null) {
        throw new EntidadeOuClasseEmBrancoOuNaoInformadaException("estado");
    }

    // Verifica se o id do EstadoModels é zero
    if (estado.getId() == 0) {
        throw new CampoEspecificoNaoInformadoException("id");
    }

    // Verifica se o id do EstadoModels é um número válido
    if (!idStr.matches("\\d+")) {
        throw new ValorInvalidoException("id");
    }

    // Verifica se o nome do EstadoModels é nulo, vazio ou contém apenas espaços em branco
    if (estado.getNome() == null
            || estado.getNome().isEmpty()
            || estado.getNome().isBlank()) {
        throw new CampoEspecificoNaoInformadoException("nome do estado");
    }

    // Verifica se o tamanho do nome do EstadoModels excede o limite de 30 caracteres
    if ((estado.getNome().length() > 30)) {
        throw new TamanhoMaximoDoCampoExcedidoException("nome do estado", 30);
    }

    // Verifica se a sigla do EstadoModels é nula, vazia ou contém apenas espaços em branco
    if (estado.getSigla() == null
            || estado.getSigla().isEmpty()
            || estado.getSigla().isBlank()) {
        throw new CampoEspecificoNaoInformadoException("sigla do estado");
    }

    // Verifica se o tamanho da sigla do EstadoModels excede o limite de 2 caracteres
    if ((estado.getSigla().length() > 2)) {
        throw new TamanhoMaximoDoCampoExcedidoException("sigla do estado", 2);
    }

    // Verifica se o RA (Registro Administrativo) do EstadoModels é nulo, vazio ou contém apenas espaços em branco
    if (estado.getRa() == null
            || estado.getRa().isEmpty()
            || estado.getRa().isBlank()) {
        throw new CampoEspecificoNaoInformadoException("ra");
    }

    // Verifica se o tamanho do RA do EstadoModels excede o limite de 8 caracteres
    if ((estado.getRa().length() > 8)) {
        throw new TamanhoMaximoDoCampoExcedidoException("ra", 8);
    }

    // Verifica se o objeto PaisModels do EstadoModels é nulo
    if (estado.getPais() == null) {
        throw new EntidadeOuClasseEmBrancoOuNaoInformadaException("pais");
    }
}

// Método responsável por retornar uma lista com todos os EstadosModels cadastrados no banco de dados
public List<EstadoModels> findAll() throws SQLException {

    EstadoDAO estadoDAO = new EstadoDAO();
    List<EstadoModels> resultado = estadoDAO.findAll();

    return resultado;
}

// Método responsável por retornar um EstadoModels específico com base no id informado
public EstadoModels findById(int id) throws SQLException, TamanhoMaximoDoCampoExcedidoException, Exception {

    // Verifica se o id informado é válido
    if (id <= 0) {
        throw new TamanhoMaximoDoCampoExcedidoException("id", 1);
    }

    EstadoDAO estadoDAO = new EstadoDAO();
    EstadoModels retorno = estadoDAO.findById(id);

    // Verifica se o objeto EstadoModels retornado é nulo
    if (retorno == null) {
        throw new Exception("Não foi possível encontrar um país com o id: " + id + " informado");
    }

    return estadoDAO.findById(id);
}

// Método responsável por inserir um novo EstadoModels no banco de dados
public void insert(EstadoModels estado) throws SQLException, EntidadeOuClasseEmBrancoOuNaoInformadaException, CampoEspecificoNaoInformadoException, TamanhoMaximoDoCampoExcedidoException, ValorInvalidoException {
    validar(estado);
    EstadoDAO estadoDAO = new EstadoDAO();
    estadoDAO.insert(estado);
}

// Método responsável por atualizar um EstadoModels existente no banco de dados
public void update(EstadoModels estado) throws SQLException, EntidadeOuClasseEmBrancoOuNaoInformadaException, CampoEspecificoNaoInformadoException, TamanhoMaximoDoCampoExcedidoException, ValorInvalidoException {
    validar(estado);
    EstadoDAO estadoDAO = new EstadoDAO();
    estadoDAO.update(estado);
}

// Método responsável por excluir um EstadoModels do banco de dados com base no id informado
public void delete(int id) throws SQLException {
    EstadoDAO estadoDAO = new EstadoDAO();
    estadoDAO.delete(id);

}
}