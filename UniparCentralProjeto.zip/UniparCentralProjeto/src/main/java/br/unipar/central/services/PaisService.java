package br.unipar.central.services;

import br.unipar.central.DAO.PaisDAO;
import br.unipar.central.exceptions.CampoEspecificoNaoInformadoException;
import br.unipar.central.exceptions.EntidadeOuClasseEmBrancoOuNaoInformadaException;
import br.unipar.central.exceptions.TamanhoMaximoDoCampoExcedidoException;
import br.unipar.central.exceptions.ValorInvalidoException;
import br.unipar.central.models.PaisModels;
import java.sql.SQLException;
import java.util.List;
  
public class PaisService {

    public void validar(PaisModels pais) throws
            EntidadeOuClasseEmBrancoOuNaoInformadaException,
            CampoEspecificoNaoInformadoException,
            TamanhoMaximoDoCampoExcedidoException,
            ValorInvalidoException {

        // Conversão do id para string para validação
        String idStr = String.valueOf(pais.getId());

        // Verifica se o objeto PaisModels é nulo
        if (pais == null) {
            throw new EntidadeOuClasseEmBrancoOuNaoInformadaException("pais");
        }

        // Verifica se o id do PaisModels é zero
        if (pais.getId() == 0) {
            throw new CampoEspecificoNaoInformadoException("id");
        }

        // Verifica se o id do PaisModels é um número válido
        if (!idStr.matches("\\d+")) {
            throw new ValorInvalidoException("id");
        }

        // Verifica se o nome do PaisModels é nulo, vazio ou contém apenas espaços em branco
        if (pais.getNome() == null
                || pais.getNome().isEmpty()
                || pais.getNome().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("nome do pais");
        }

        // Verifica se o tamanho do nome do PaisModels excede o limite de 60 caracteres
        if ((pais.getNome().length() > 60)) {
            throw new TamanhoMaximoDoCampoExcedidoException("nome do pais", 60);
        }

        // Verifica se a sigla do PaisModels é nula, vazia ou contém apenas espaços em branco
        if (pais.getSigla() == null
                || pais.getSigla().isEmpty()
                || pais.getSigla().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("sigla");
        }

        // Verifica se o tamanho da sigla do PaisModels excede o limite de 3 caracteres
        if ((pais.getSigla().length() == 3)) {
            throw new TamanhoMaximoDoCampoExcedidoException("sigla", 3);
        }

        // Verifica se o RA (Registro Administrativo) do PaisModels é nulo, vazio ou contém apenas espaços em branco
        if (pais.getRa() == null
                || pais.getRa().isEmpty()
                || pais.getRa().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("ra");
        }

        // Verifica se o tamanho do RA do PaisModels excede o limite de 8 caracteres
        if ((pais.getRa().length() > 8)) {
            throw new TamanhoMaximoDoCampoExcedidoException("ra", 8);
        }

    }

    // Método responsável por retornar uma lista com todos os PaisModels cadastrados no banco de dados
    public List<PaisModels> findAll() throws SQLException {

        PaisDAO paisDAO = new PaisDAO();
        List<PaisModels> resultado = paisDAO.findAll();

        return resultado;
    }

    // Método responsável por retornar um PaisModels específico com base no id informado
    public PaisModels findById(int id) throws SQLException, TamanhoMaximoDoCampoExcedidoException, Exception {

        // Verifica se o id informado é válido
        if (id <= 0) {
            throw new TamanhoMaximoDoCampoExcedidoException("id", 1);
        }

        PaisDAO paisDAO = new PaisDAO();
        PaisModels retorno = paisDAO.findById(id);

        // Verifica se o objeto PaisModels encontrado é nulo
        if (retorno == null) {
            throw new Exception("Não foi possível encontrar um país com o id: " + id + " informado");
        }

        return paisDAO.findById(id);
    }

    // Método responsável por inserir um novo PaisModels no banco de dados
    public void insert(PaisModels pais) throws SQLException, EntidadeOuClasseEmBrancoOuNaoInformadaException, CampoEspecificoNaoInformadoException, TamanhoMaximoDoCampoExcedidoException, ValorInvalidoException {
        
        // Valida os campos do objeto PaisModels antes de inseri-lo
        validar(pais);
        PaisDAO paisDAO = new PaisDAO();
        paisDAO.insert(pais);
    }

    // Método responsável por atualizar um PaisModels já existente no banco de dados
    public void update(PaisModels pais) throws SQLException, EntidadeOuClasseEmBrancoOuNaoInformadaException, CampoEspecificoNaoInformadoException, TamanhoMaximoDoCampoExcedidoException, ValorInvalidoException {
        
        // Valida os campos do objeto PaisModels antes de atualizá-lo
        validar(pais);
        PaisDAO paisDAO = new PaisDAO();
        paisDAO.update(pais);
    }

    // Método responsável por excluir um PaisModels com base no id informado
    public void delete(int id) throws SQLException {
        PaisDAO paisDAO = new PaisDAO();
        paisDAO.delete(id);
    }
}