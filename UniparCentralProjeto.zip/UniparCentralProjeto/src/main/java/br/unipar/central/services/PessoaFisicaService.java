package br.unipar.central.services;

import br.unipar.central.DAO.PessoaFisicaDAO;
import br.unipar.central.exceptions.CampoEspecificoNaoInformadoException;
import br.unipar.central.exceptions.EntidadeOuClasseEmBrancoOuNaoInformadaException;
import br.unipar.central.exceptions.TamanhoMaximoDoCampoExcedidoException;
import br.unipar.central.exceptions.ValorInvalidoException;
import br.unipar.central.models.PessoaFisicaModels;
import java.sql.SQLException;
import java.util.List;

public class PessoaFisicaService {
    
    // Método responsável por validar os dados de uma pessoa física
public void validar(PessoaFisicaModels pessoaFP) throws
        EntidadeOuClasseEmBrancoOuNaoInformadaException,
        CampoEspecificoNaoInformadoException,
        TamanhoMaximoDoCampoExcedidoException,
        ValorInvalidoException {

    // Verifica se a pessoa física é nula
    if (pessoaFP == null) {
        throw new EntidadeOuClasseEmBrancoOuNaoInformadaException("pessoa física");
    }

    // Verifica se o nome da pessoa física foi informado
    if (pessoaFP.getNome() == null
            || pessoaFP.getNome().isEmpty()
            || pessoaFP.getNome().isBlank()) {
        throw new CampoEspecificoNaoInformadoException("nome");
    }

    // Verifica se o tamanho do nome da pessoa física não excede o tamanho máximo permitido
    if ((pessoaFP.getNome().length() > 60)) {
        throw new TamanhoMaximoDoCampoExcedidoException("nome", 60);
    }

    // Verifica se o CPF da pessoa física foi informado
    if (pessoaFP.getCpf() == null
            || pessoaFP.getCpf().isEmpty()
            || pessoaFP.getCpf().isBlank()) {
        throw new CampoEspecificoNaoInformadoException("cpf");
    }

    // Verifica se o tamanho do CPF da pessoa física não excede o tamanho máximo permitido
    if ((pessoaFP.getCpf().length() > 11)) {
        throw new TamanhoMaximoDoCampoExcedidoException("cpf", 11);
    }

    // Verifica se o RG da pessoa física foi informado
    if (pessoaFP.getRg() == null
            || pessoaFP.getRg().isEmpty()
            || pessoaFP.getRg().isBlank()) {
        throw new CampoEspecificoNaoInformadoException("rg");
    }

    // Verifica se o tamanho do RG da pessoa física não excede o tamanho máximo permitido
    if ((pessoaFP.getRg().length() == 15)) {
        throw new TamanhoMaximoDoCampoExcedidoException("rg", 15);
    }
    
    // Verifica se a pessoa física está associada a uma pessoa
    if (pessoaFP.getPessoa() == null) {
        throw new EntidadeOuClasseEmBrancoOuNaoInformadaException("pessoa");
    }
}

// Método responsável por buscar todas as pessoas físicas cadastradas
public List<PessoaFisicaModels> findAll() throws SQLException {

    // Instancia um objeto do DAO de Pessoa Física
    PessoaFisicaDAO pessoaFisicaDAO = new PessoaFisicaDAO();

    // Busca todas as pessoas físicas cadastradas
    List<PessoaFisicaModels> resultado = pessoaFisicaDAO.findAll();

    // Retorna a lista de pessoas físicas
    return resultado;
}

// Método responsável por buscar uma pessoa física pelo seu CPF
public PessoaFisicaModels findById(String cpf) throws SQLException, TamanhoMaximoDoCampoExcedidoException, Exception {

    // Verifica se o tamanho do CPF informado é válido
    if (cpf.length() <= 0) {
        throw new TamanhoMaximoDoCampoExcedidoException("cpf", 1);
    }

    // Instancia um objeto do DAO de Pessoa Física
    PessoaFisicaDAO pessoaFisicaDAO = new PessoaFisicaDAO();

    // Busca a pessoa física pelo CPF
    PessoaFisicaModels retorno = pessoaFisicaDAO.findById(cpf);

    // Verifica se a pessoa física foi encontrada
    if (retorno == null) {
        throw new Exception("Não foi possível encontrar uma pessoa física com o CPF: " + cpf + " informado");
    }

    // Retorna a pessoafísica encontrada
    return retorno;
}

// Método responsável por inserir uma nova pessoa física no banco de dados
public void insert(PessoaFisicaModels pessoaFisica) throws SQLException, EntidadeOuClasseEmBrancoOuNaoInformadaException, CampoEspecificoNaoInformadoException, TamanhoMaximoDoCampoExcedidoException, ValorInvalidoException {
    // Valida os dados da pessoa física
    validar(pessoaFisica);

    // Instancia um objeto do DAO de Pessoa Física
    PessoaFisicaDAO pessoaFisicaDAO = new PessoaFisicaDAO();

    // Insere a pessoa física no banco de dados
    pessoaFisicaDAO.insert(pessoaFisica);
}

// Método responsável por atualizar os dados de uma pessoa física no banco de dados
public void update(PessoaFisicaModels pessoaFisica) throws SQLException, EntidadeOuClasseEmBrancoOuNaoInformadaException, CampoEspecificoNaoInformadoException, TamanhoMaximoDoCampoExcedidoException, ValorInvalidoException {
    // Valida os dados da pessoa física
    validar(pessoaFisica);

    // Instancia um objeto do DAO de Pessoa Física
    PessoaFisicaDAO pessoaFisicaDAO = new PessoaFisicaDAO();

    // Atualiza os dados da pessoa física no banco de dados
    pessoaFisicaDAO.update(pessoaFisica);
}

// Método responsável por excluir uma pessoa física do banco de dados
public void delete(String cpf) throws SQLException {
    // Instancia um objeto do DAO de Pessoa Física
    PessoaFisicaDAO pessoaFisicaDAO = new PessoaFisicaDAO();

    // Exclui a pessoa física do banco de dados
    pessoaFisicaDAO.delete(cpf);
}
}