// Pacote responsável por fornecer serviços relacionados às pessoas jurídicas
package br.unipar.central.services;

import br.unipar.central.DAO.PessoaJuridicaDAO;
import br.unipar.central.exceptions.CampoEspecificoNaoInformadoException;
import br.unipar.central.exceptions.EntidadeOuClasseEmBrancoOuNaoInformadaException;
import br.unipar.central.exceptions.TamanhoMaximoDoCampoExcedidoException;
import br.unipar.central.exceptions.ValorInvalidoException;
import br.unipar.central.models.PessoaJuridicaModels;
import java.sql.SQLException;
import java.util.List;

public class PessoaJuridicaService {

    // Método responsável por validar os campos de um objeto PessoaJuridicaModels
    public void validar(PessoaJuridicaModels PJPJ) throws
            EntidadeOuClasseEmBrancoOuNaoInformadaException,
            CampoEspecificoNaoInformadoException,
            TamanhoMaximoDoCampoExcedidoException,
            ValorInvalidoException {

        // Verifica se o objeto PessoaJuridicaModels é nulo
        if (PJPJ == null) {
            throw new EntidadeOuClasseEmBrancoOuNaoInformadaException("pais");
        }

        // Verifica se a razão social da PessoaJuridicaModels é nula, vazia ou contém apenas espaços em branco
        if (PJPJ.getRazaoSocial() == null
                || PJPJ.getRazaoSocial().isEmpty()
                || PJPJ.getRazaoSocial().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("razão social");
        }

        // Verifica se o tamanho da razão social da PessoaJuridicaModels excede o limite de 60 caracteres
        if ((PJPJ.getRazaoSocial().length() > 60)) {
            throw new TamanhoMaximoDoCampoExcedidoException("razão social", 60);
        }
        
        // Verifica se o CNPJ da PessoaJuridicaModels é nulo, vazio ou contém apenas espaços em branco
        if (PJPJ.getCNPJ()== null
                || PJPJ.getCNPJ().isEmpty()
                || PJPJ.getCNPJ().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("cpf");
        }

        // Verifica se o tamanho do CNPJ da PessoaJuridicaModels excede o limite de 18 caracteres
        if ((PJPJ.getCNPJ().length() > 18)) {
            throw new TamanhoMaximoDoCampoExcedidoException("cpf", 18);
        }

        // Verifica se o nome fantasia da PessoaJuridicaModels é nulo, vazio ou contém apenas espaços em branco
        if (PJPJ.getNomeFantasia() == null
                || PJPJ.getNomeFantasia().isEmpty()
                || PJPJ.getNomeFantasia().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("nome fantasia");
        }

        // Verifica se o tamanho do nome fantasia da PessoaJuridicaModels excede o limite de 60 caracteres
        if ((PJPJ.getNomeFantasia().length() > 60)) {
            throw new TamanhoMaximoDoCampoExcedidoException("nome fantasia", 60);
        }

        // Verifica se o CNAE principal da PessoaJuridicaModels é nulo, vazio ou contém apenas espaços em branco
        if (PJPJ.getCnaePrincipal() == null
                || PJPJ.getCnaePrincipal().isEmpty()
                || PJPJ.getCnaePrincipal().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("cnae");
        }

        // Verifica se o tamanho do CNAE principal da PessoaJuridicaModels excede o limite de 100 caracteres
        if ((PJPJ.getCnaePrincipal().length() > 100)) {
            throw new TamanhoMaximoDoCampoExcedidoException("cnae", 100);
        }

        // Verifica se o objeto Pessoa da PessoaJuridicaModels é nulo
        if (PJPJ.getPessoa() == null) {
            throw new EntidadeOuClasseEmBrancoOuNaoInformadaException("pessoa");
        }

    }

    // Método responsável por retornar uma lista com todas as PessoaJuridicaModels cadastradas no banco de dados
    public List<PessoaJuridicaModels> findAll() throws SQLException {

        PessoaJuridicaDAO pessoaJuridicaDAO = new PessoaJuridicaDAO();
        List<PessoaJuridicaModels> resultado = pessoaJuridicaDAO.findAll();

        return resultado;
    }

    // Método responsável por buscar uma PessoaJuridicaModels no banco de dados com base no seu CNPJ
    public PessoaJuridicaModels findById(String cnpj) throws SQLException, TamanhoMaximoDoCampoExcedidoException, Exception {

        // Verifica se o tamanho do CNPJ é maior do que zero
        if (cnpj.length() <= 0) {
            throw new TamanhoMaximoDoCampoExcedidoException("cnpj", 1);
        }

        PessoaJuridicaDAO pessoaJuridicaDAO = new PessoaJuridicaDAO();
        PessoaJuridicaModels retorno = pessoaJuridicaDAO.findById(cnpj);

        // Verifica se a busca no banco de dados retornou uma PessoaJuridicaModels
        if (retorno == null) {
            throw new Exception("Não foi possível encontrar uma pessoa jurídica com o CNPJ: " + cnpj + " informado");
        }

        return pessoaJuridicaDAO.findById(cnpj);
    }

    // Método responsável por inserir uma nova PessoaJuridicaModels no banco de dados
    public void insert(PessoaJuridicaModels pessoaJuridica) throws SQLException, EntidadeOuClasseEmBrancoOuNaoInformadaException, CampoEspecificoNaoInformadoException, TamanhoMaximoDoCampoExcedidoException, ValorInvalidoException {
        validar(pessoaJuridica); // Valida os campos da PessoaJuridicaModels antes de inseri-la no banco de dados
        PessoaJuridicaDAO pessoaJuridicaDAO = new PessoaJuridicaDAO();
        pessoaJuridicaDAO.insert(pessoaJuridica);
    }

    // Método responsável por atualizar uma PessoaJuridicaModels existente no banco de dados
    public void update(PessoaJuridicaModels pessoaJuridica) throws SQLException, EntidadeOuClasseEmBrancoOuNaoInformadaException, CampoEspecificoNaoInformadoException, TamanhoMaximoDoCampoExcedidoException, ValorInvalidoException {
        validar(pessoaJuridica); // Valida os campos da PessoaJuridicaModels antes de atualizá-la no banco de dados
        PessoaJuridicaDAO pessoaJuridicaDAO = new PessoaJuridicaDAO();
        pessoaJuridicaDAO.update(pessoaJuridica);
    }

    // Método responsável por excluir uma PessoaJuridicaModels do banco de dados com base no seu CNPJ
    public void delete(String cnpj) throws SQLException {
        PessoaJuridicaDAO pessoaJuridicaDAO = new PessoaJuridicaDAO();
        pessoaJuridicaDAO.delete(cnpj);

    }
}