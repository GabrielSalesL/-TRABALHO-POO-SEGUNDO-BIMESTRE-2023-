// Pacote responsável por fornecer serviços relacionados às pessoas
package br.unipar.central.services;

import br.unipar.central.DAO.PessoaDAO;
import br.unipar.central.exceptions.CampoEspecificoNaoInformadoException;
import br.unipar.central.exceptions.EntidadeOuClasseEmBrancoOuNaoInformadaException;
import br.unipar.central.exceptions.TamanhoMaximoDoCampoExcedidoException;
import br.unipar.central.exceptions.ValorInvalidoException;
import br.unipar.central.models.PessoaModels;
import java.sql.SQLException;
import java.util.List;

public class PessoaService {

    // Método responsável por validar os campos de um objeto PessoaModels
    public void validar(PessoaModels pessoa) throws
            EntidadeOuClasseEmBrancoOuNaoInformadaException,
            CampoEspecificoNaoInformadoException,
            TamanhoMaximoDoCampoExcedidoException,
            ValorInvalidoException {

        // Converte o id do objeto PessoaModels para uma string
        String idStr = String.valueOf(pessoa.getId());

        // Verifica se o objeto PessoaModels é nulo
        if (pessoa == null) {
            throw new EntidadeOuClasseEmBrancoOuNaoInformadaException("pessoa");
        }

        // Verifica se o id do PessoaModels é zero
        if (pessoa.getId() == 0) {
            throw new CampoEspecificoNaoInformadoException("id");
        }

        // Verifica se o id do PessoaModels é um número inteiro válido
        if (!idStr.matches("\\d+")) {
            throw new ValorInvalidoException("id");
        }

        // Verifica se o email do PessoaModels é nulo, vazio ou contém apenas espaços em branco
        if (pessoa.getEmail() == null
                || pessoa.getEmail().isEmpty()
                || pessoa.getEmail().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("email");
        }

        // Verifica se o tamanho do email do PessoaModels excede o limite de 100 caracteres
        if ((pessoa.getEmail().length() > 100)) {
            throw new TamanhoMaximoDoCampoExcedidoException("email", 100);
        }

        // Verifica se o RA do PessoaModels é nulo, vazio ou contém apenas espaços em branco
        if (pessoa.getRa() == null
                || pessoa.getRa().isEmpty()
                || pessoa.getRa().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("ra");
        }

        // Verifica se o tamanho do RA do PessoaModels excede o limite de 8 caracteres
        if ((pessoa.getRa().length() > 8)) {
            throw new TamanhoMaximoDoCampoExcedidoException("ra", 8);
        }

    }

    // Método responsável por retornar uma lista com todas as PessoaModels cadastradas no banco de dados
    public List<PessoaModels> findAll() throws SQLException {

        PessoaDAO pessoaDAO = new PessoaDAO();
        List<PessoaModels> resultado = pessoaDAO.findAll();

        return resultado;
    }

    // Método responsável por retornar uma PessoaModels específica com base no id informado
    public PessoaModels findById(int id) throws SQLException, TamanhoMaximoDoCampoExcedidoException, Exception {

        // Verifica se o id informado é válido
        if (id <= 0) {
            throw new TamanhoMaximoDoCampoExcedidoException("id", 1);
        }

        PessoaDAO pessoaDAO = new PessoaDAO();
        PessoaModels retorno = pessoaDAO.findById(id);

        // Verifica se o objeto PessoaModels encontrado é nulo
        if (retorno == null) {
            throw new Exception("Não foi possível encontrar uma pessoa com o id: " + id + " informado");
        }

        return pessoaDAO.findById(id);
    }

    // Método responsável por atualizar uma PessoaModels existente no banco de dados
    public void update(PessoaModels pessoa) throws SQLException, EntidadeOuClasseEmBrancoOuNaoInformadaException, CampoEspecificoNaoInformadoException, TamanhoMaximoDoCampoExcedidoException, ValorInvalidoException {
        validar(pessoa);
        PessoaDAO pessoaDAO = new PessoaDAO();
        pessoaDAO.update(pessoa);
    }

    // Método responsável por excluir uma PessoaModels do banco de dados com base no id informado
    public void delete(int id) throws SQLException {
        PessoaDAO pessoaDAO = new PessoaDAO();
        pessoaDAO.delete(id);

    }

    public void insert(PessoaModels pessoa) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
    
