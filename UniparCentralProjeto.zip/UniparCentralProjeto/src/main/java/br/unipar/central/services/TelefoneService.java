package br.unipar.central.services;

import br.unipar.central.DAO.TelefoneDAO;
import br.unipar.central.exceptions.CampoEspecificoNaoInformadoException;
import br.unipar.central.exceptions.EntidadeOuClasseEmBrancoOuNaoInformadaException;
import br.unipar.central.exceptions.TamanhoMaximoDoCampoExcedidoException;
import br.unipar.central.exceptions.ValorInvalidoException;
import br.unipar.central.models.TelefoneModels;
import java.sql.SQLException;
import java.util.List;

public class TelefoneService {

    // Método responsável por validar os campos de um objeto TelefoneModels
    public void validar(TelefoneModels telefone) throws
            EntidadeOuClasseEmBrancoOuNaoInformadaException,
            CampoEspecificoNaoInformadoException,
            TamanhoMaximoDoCampoExcedidoException,
            ValorInvalidoException {

        // Converte o id do objeto TelefoneModels para uma string
        String idStr = String.valueOf(telefone.getId());

        // Verifica se o objeto TelefoneModels é nulo
        if (telefone == null) {
            throw new EntidadeOuClasseEmBrancoOuNaoInformadaException("telefone");
        }

        // Verifica se o id do TelefoneModels é zero
        if (telefone.getId() == 0) {
            throw new CampoEspecificoNaoInformadoException("id");
        }

        // Verifica se o id do TelefoneModels é um número inteiro válido
        if (!idStr.matches("\\d+")) {
            throw new ValorInvalidoException("id");
        }

        // Verifica se o número do TelefoneModels é nulo, vazio ou contém apenas espaços em branco
        if (telefone.getNumero() == null
                || telefone.getNumero().isEmpty()
                || telefone.getNumero().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("numero do telefone");
        }

        // Verifica se o tamanho do número do TelefoneModels excede o limite de 8 caracteres
        if ((telefone.getNumero().length() > 8)) {
            throw new TamanhoMaximoDoCampoExcedidoException("numero do telefone", 8);
        }

        // Verifica se a operadora do TelefoneModels é nula
        if (telefone.getOperadora() == null) {
            throw new CampoEspecificoNaoInformadoException("operadora");
        }

        // Verifica se o RA do TelefoneModels é nulo, vazio ou contém apenas espaços em branco
        if (telefone.getRa() == null
                || telefone.getRa().isEmpty()
                || telefone.getRa().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("ra");
        }

        // Verifica se o tamanho do RA do TelefoneModels excede o limite de 8 caracteres
        if ((telefone.getRa().length() > 8)) {
            throw new TamanhoMaximoDoCampoExcedidoException("ra", 8);
        }

        // Verifica se a agência do TelefoneModels é nula
        if (telefone.getAgencia() == null) {
            throw new EntidadeOuClasseEmBrancoOuNaoInformadaException("agencia");
        }

        // Verifica se a pessoa do TelefoneModels é nula
        if (telefone.getPessoa() == null) {
            throw new EntidadeOuClasseEmBrancoOuNaoInformadaException("pessoa");
        }

    }

    // Método responsável por retornar uma lista com todos os TelefoneModels cadastrados no banco de dados
    public List<TelefoneModels> findAll() throws SQLException {

        TelefoneDAO telefoneDAO = new TelefoneDAO();
        List<TelefoneModels> resultado = telefoneDAO.findAll();

        return resultado;
    }

    // Método responsável por retornar um TelefoneModels específico com base no id informado
    public TelefoneModels findById(int id) throws SQLException, TamanhoMaximoDoCampoExcedidoException, Exception {

        // Verifica se o id informado é válido
        if (id <= 0) {
            throw new TamanhoMaximoDoCampoExcedidoException("id", 1);
        }

        TelefoneDAO telefoneDAO = new TelefoneDAO();
        TelefoneModels retorno = telefoneDAO.findById(id);

        // Verifica se o objeto TelefoneModels encontrado é nulo
        if (retorno == null) {
            throw new Exception("Não foi possível encontrar um telefone com o id: " + id + " informado");
       }

        return telefoneDAO.findById(id);
    }

    // Método responsável por inserir um novo TelefoneModels no banco de dados
    public void insert(TelefoneModels telefone) throws SQLException, EntidadeOuClasseEmBrancoOuNaoInformadaException, CampoEspecificoNaoInformadoException, TamanhoMaximoDoCampoExcedidoException, ValorInvalidoException {
        validar(telefone);
        TelefoneDAO telefoneDAO = new TelefoneDAO();
        telefoneDAO.insert(telefone);
    }

    // Método responsável por atualizar um TelefoneModels existente no banco de dados
    public void update(TelefoneModels telefone) throws SQLException, EntidadeOuClasseEmBrancoOuNaoInformadaException, CampoEspecificoNaoInformadoException, TamanhoMaximoDoCampoExcedidoException, ValorInvalidoException {
        validar(telefone);
        TelefoneDAO telefoneDAO = new TelefoneDAO();
        telefoneDAO.update(telefone);
    }

    // Método responsável por excluir um TelefoneModels do banco de dados com base no id informado
    public void delete(int id) throws SQLException {
        TelefoneDAO telefoneDAO = new TelefoneDAO();
        telefoneDAO.delete(id);

    }
}