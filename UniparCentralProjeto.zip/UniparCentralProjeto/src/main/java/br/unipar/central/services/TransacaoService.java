package br.unipar.central.services;

import br.unipar.central.DAO.TransacaoDAO;
import br.unipar.central.exceptions.CampoEspecificoNaoInformadoException;
import br.unipar.central.exceptions.EntidadeOuClasseEmBrancoOuNaoInformadaException;
import br.unipar.central.exceptions.TamanhoMaximoDoCampoExcedidoException;
import br.unipar.central.exceptions.ValorInvalidoException;
import br.unipar.central.models.TransacaoModels;
import java.sql.SQLException;
import java.util.List;

public class TransacaoService {

    // Método responsável por validar os campos de um objeto TransacaoModels
    public void validar(TransacaoModels transacao) throws
            EntidadeOuClasseEmBrancoOuNaoInformadaException,
            CampoEspecificoNaoInformadoException,
            TamanhoMaximoDoCampoExcedidoException {

        // Verifica se o objeto TransacaoModels é nulo
        if (transacao == null) {
            throw new EntidadeOuClasseEmBrancoOuNaoInformadaException("transacao");
        }

        // Verifica se o id do TransacaoModels é zero
        if (transacao.getId() == 0) {
            throw new CampoEspecificoNaoInformadoException("id");
        }

        // Verifica se o valor do TransacaoModels é zero
        if (transacao.getValor() == 0) {
            throw new CampoEspecificoNaoInformadoException("saldo em conta");
        }

        // Verifica se a data e hora do TransacaoModels são nulas
        if (transacao.getDatahora()== null) {
            throw new EntidadeOuClasseEmBrancoOuNaoInformadaException("Data e Hora da transação");
        }
        
        // Verifica se o tamanho do RA do TransacaoModels excede o limite de 8 caracteres
        if ((transacao.getRa().length() > 8)) {
            throw new TamanhoMaximoDoCampoExcedidoException("ra", 8);
        }

        // Verifica se o tipo do TransacaoModels é nulo
        if (transacao.getTipo() == null) {
            throw new CampoEspecificoNaoInformadoException("tipo da transação");
        }

        // Verifica se o RA do TransacaoModels é nulo, vazio ou contém apenas espaços em branco
        if (transacao.getRa() == null
                || transacao.getRa().isEmpty()
                || transacao.getRa().isBlank()) {
            throw new CampoEspecificoNaoInformadoException("ra");
        }

        // Verifica se o tamanho do RA do TransacaoModels excede o limite de 8 caracteres
        if ((transacao.getRa().length() > 8)) {
            throw new TamanhoMaximoDoCampoExcedidoException("ra", 8);
        }

        // Verifica se a conta de destino do TransacaoModels é zero
        if (transacao.getConta_destino() == 0) {
            throw new EntidadeOuClasseEmBrancoOuNaoInformadaException("agencia");
        }

        // Verifica se a conta de origem do TransacaoModels é zero
        if (transacao.getConta_origem() == 0) {
            throw new EntidadeOuClasseEmBrancoOuNaoInformadaException("pessoa");
        }

    }

    // Método responsável por retornar uma lista com todas as TransacaoModels cadastradas no banco de dados
    public List<TransacaoModels> findAll() throws SQLException {

        TransacaoDAO transacaoDAO = new TransacaoDAO();
        List<TransacaoModels> resultado = transacaoDAO.findAll();

        return resultado;
    }

    // Método responsável por retornar uma TransacaoModels específica com base no id informado
    public TransacaoModels findById(int id) throws SQLException, TamanhoMaximoDoCampoExcedidoException, Exception {

        // Verifica se o id informado é válido
        if (id <= 0) {
            throw new TamanhoMaximoDoCampoExcedidoException("id", 1);
        }

        TransacaoDAO transacaoDAO = new TransacaoDAO();
        TransacaoModels retorno = transacaoDAO.findById(id);

        // Verifica se o objeto TransacaoModels encontrado é nulo
        if (retorno == null) {
            throw new Exception("Não foi possível encontrar uma transação com o id: " + id + " informado");
        }

        return transacaoDAO.findById(id);
    }

    // Método responsável por inserir umanova TransacaoModels no banco de dados
    public void insert(TransacaoModels transacao) throws SQLException, EntidadeOuClasseEmBrancoOuNaoInformadaException, CampoEspecificoNaoInformadoException, TamanhoMaximoDoCampoExcedidoException, ValorInvalidoException {
        validar(transacao); // Valida os campos do objeto TransacaoModels
        TransacaoDAO transacaoDAO = new TransacaoDAO();
        transacaoDAO.insert(transacao); // Insere o objeto TransacaoModels no banco de dados
    }

    // Método responsável por atualizar uma TransacaoModels já existente no banco de dados
    public void update(TransacaoModels transacao) throws SQLException, EntidadeOuClasseEmBrancoOuNaoInformadaException, CampoEspecificoNaoInformadoException, TamanhoMaximoDoCampoExcedidoException, ValorInvalidoException {
        validar(transacao); // Valida os campos do objeto TransacaoModels
        TransacaoDAO transacaoDAO = new TransacaoDAO();
        transacaoDAO.update(transacao); // Atualiza o objeto TransacaoModels no banco de dados
    }

    // Método responsável por excluir uma TransacaoModels do banco de dados com base no id informado
    public void delete(int id) throws SQLException {
        TransacaoDAO transacaoDAO = new TransacaoDAO();
        transacaoDAO.delete(id); // Exclui a TransacaoModels do banco de dados
    }
}